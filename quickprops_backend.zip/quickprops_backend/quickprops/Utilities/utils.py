# Standard Library Imports
from random import randint
import re
import string
import secrets
import time
from datetime import datetime, timedelta

# Django Imports
from django.conf import settings

# Third-party Imports
import requests
import base64
import sendgrid
from sendgrid.helpers.mail import Mail

def generate_otp(n):
    # Calculate the start and end range for the OTP
    range_start = 10**(n-1)
    range_end = (10**n)-1
    return randint(range_start, range_end)

def send_email_otp(user, otp):
    sg = sendgrid.SendGridAPIClient(api_key=settings.SENDGRID_API_KEY)
    from_email = settings.SENDGRID_EMAIL
    to_emails = user.email
    subject = "Your OTP Code"
    with open('quickprops_app/templates/otp.html', 'r') as file:
        content = file.read()
    content = content.replace('{{name}}', user.full_name)
    content = content.replace('{{otp}}', str(otp))
    # Create a Mail object
    mail = Mail(
        from_email=from_email,
        to_emails=to_emails,
        subject=subject,
        html_content=content
    )

    # Get a JSON-ready representation of the Mail object
    mail_json = mail.get()
    try:
        response = sg.client.mail.send.post(request_body=mail_json)
        if response.status_code == 202:
            print(f"Email sent successfully to {user.email}: Status Code {response.status_code}")
            return response.status_code == 202
        else:
            print(f"Failed to send email to {user.email}: Status Code {response.status_code}")

        print(response.headers)
    except Exception as e:
        # Detailed logging for debugging
        print(f"Error sending email: {e}")
        if hasattr(e, 'code'):
            print(f"Error code: {e.code}")
        if hasattr(e, 'body'):
            print(f"Error body: {e.body}")


def send_phone_otp(phone_number, otp):
    api_url = "https://api.bulksms.com/v1/messages"
    my_username = settings.MY_SMS_USERNAME
    my_password = settings.MY_PASSWORD

    if not phone_number.startswith("0"):
        phone_number = "27" + phone_number

    my_data = {
        "to": [phone_number],
        "body": f"Your OTP is: {otp}",
        "encoding": "TEXT",
        "longMessageMaxParts": "3"
    }
    credentials = f"{my_username}:{my_password}"
    encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Basic {encoded_credentials}"
    }

    try:
        response = requests.post(
            api_url,
            json=my_data,
            headers=headers
        )
        # Check if the request was successful
        response.raise_for_status()

        # Print the response from the API
        return response
    except requests.exceptions.RequestException as ex:
        # Show the general message
        print("An error occurred: {}".format(ex))
        # Print the detail that comes with the error if available
        if ex.response is not None:
            print("Error details: {}".format(ex.response.text))


def send_email_resend_otp(user, otp):
    sg = sendgrid.SendGridAPIClient(api_key=settings.SENDGRID_API_KEY)

    from_email = settings.SENDGRID_EMAIL
    to_emails = user.email
    subject = "Your OTP Code"
    with open('quickprops_app/templates/resend_otp.html', 'r') as file:
        content = file.read()
    content = content.replace('{{name}}', user.full_name)
    content = content.replace('{{otp}}', str(otp))
    # Create a Mail object
    mail = Mail(
        from_email=from_email,
        to_emails=to_emails,
        subject=subject,
        html_content=content
    )

    # Get a JSON-ready representation of the Mail object
    mail_json = mail.get()
    try:
        response = sg.client.mail.send.post(request_body=mail_json)
        if response.status_code == 202:
            print(f"Email sent successfully to {user.email}: Status Code {response.status_code}")
            return response.status_code == 202
        else:
            print(f"Failed to send email to {user.email}: Status Code {response.status_code}")

        print(response.headers)
    except Exception as e:
        # Detailed logging for debugging
        print(f"Error sending email: {e}")
        if hasattr(e, 'code'):
            print(f"Error code: {e.code}")
        if hasattr(e, 'body'):
            print(f"Error body: {e.body}")

def send_password_reset_otp(user, otp_code):
    sg = sendgrid.SendGridAPIClient(api_key=settings.SENDGRID_API_KEY)
    from_email = settings.SENDGRID_EMAIL
    to_emails = user.email
    subject = "Password Reset Request"

    # Load the email template for the password reset
    with open('quickprops_app/templates/forgot_password_email.html', 'r') as file:
        content = file.read()

    if user.full_name:
        name = user.full_name
    else:
        name = user.email

    # Replace placeholders in the template
    content = content.replace('{{name}}', name)
    content = content.replace('{{otp}}', str(otp_code))

    # Create a Mail object
    mail = Mail(
        from_email=from_email,
        to_emails=to_emails,
        subject=subject,
        html_content=content
    )

    # Get a JSON-ready representation of the Mail object
    mail_json = mail.get()

    try:
        response = sg.client.mail.send.post(request_body=mail_json)
        if response.status_code == 202:
            print(f"Password reset email sent successfully to {user.email}: Status Code {response.status_code}")
            return response.status_code == 202
        else:
            print(f"Failed to send email to {user.email}: Status Code {response.status_code}")
            print(response.headers)
    except Exception as e:
        # Detailed logging for debugging
        print(f"Error sending email: {e}")
        if hasattr(e, 'code'):
            print(f"Error code: {e.code}")
        if hasattr(e, 'body'):
            print(f"Error body: {e.body}")

# Valid Email Format
def is_valid_email(email):
    # Regular expression for validating an Email
    email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(email_regex, email) is not None

# Helper function to validate password
def validate_password(password):
    """
    This function validates the password based on various criteria.
    Returns an error message if the password does not meet the criteria,
    or None if the password is valid.
    """
    if len(password) < 8:
        return 'Password must be at least 8 characters long.'

    if not any(char.isdigit() for char in password):
        return 'Password must contain at least one digit.'

    if not any(char.islower() for char in password):
        return 'Password must contain at least one lowercase letter.'

    if not any(char.isupper() for char in password):
        return 'Password must contain at least one uppercase letter.'

    if not any(char in '!@#$%^&*()-_=+[{]};:\'",<.>/?\\|' for char in password):
        return 'Password must contain at least one special character.'

    return None  # Password is valid

def generate_random_password(length=8):
    """Generate a random password containing exactly 8 characters with specific criteria:

    The password will contain:
    - Exactly 2 lowercase letters.
    - Exactly 2 uppercase letters.
    - Exactly 2 digits.
    - Exactly 2 special characters.
    """
    # Ensure the password length is exactly 8
    if length != 8:
        raise ValueError("Password length must be exactly 8 characters.")

    # Define character sets
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    special_characters = string.punctuation

    # # Ensure the password contains at least one of each required character type
    # password = [
    #     secrets.choice(lowercase),
    #     secrets.choice(uppercase),
    #     secrets.choice(digits),
    #     secrets.choice(special_characters),
    # ]

    # Ensure the password contains 2 of each required character type
    password = [
        secrets.choice(lowercase), secrets.choice(lowercase),  # 2 lowercase letters
        secrets.choice(uppercase), secrets.choice(uppercase),  # 2 uppercase letters
        secrets.choice(digits), secrets.choice(digits),        # 2 digits
        secrets.choice(special_characters), secrets.choice(special_characters)  # 2 special characters
    ]

    # # Fill the rest of the password length with random choices from all character sets
    # all_characters = lowercase + uppercase + digits + special_characters
    # password += [secrets.choice(all_characters) for _ in range(length - 4)]

    # Shuffle the password list to ensure randomness
    secrets.SystemRandom().shuffle(password)

    return ''.join(password)

def send_password_via_email(user, password):
    sg = sendgrid.SendGridAPIClient(api_key=settings.SENDGRID_API_KEY)

    from_email = settings.SENDGRID_EMAIL
    to_emails = user.email
    subject = "Your Account Password"

    # Read and customize the HTML template
    with open('quickprops_admin/templates/send_password.html', 'r') as file:
        content = file.read()

    # Replace placeholders in the template
    content = content.replace('{{name}}', user.full_name)
    content = content.replace('{{password}}', str(password))
    content = content.replace('{{email}}', user.email)

    # Create a Mail object
    mail = Mail(
        from_email=from_email,
        to_emails=to_emails,
        subject=subject,
        html_content=content
    )

    # Get a JSON-ready representation of the Mail object
    mail_json = mail.get()

    try:
        response = sg.client.mail.send.post(request_body=mail_json)
        if response.status_code == 202:
            return response.status_code == 202
        else:
            print(response.headers)
    except Exception as e:
        # Detailed logging for debugging
        print(f"Error sending password email: {e}")
        if hasattr(e, 'code'):
            print(f"Error code: {e.code}")
        if hasattr(e, 'body'):
            print(f"Error body: {e.body}")

def send_application_status_update_email(application, status, rejection_message, property_details):
    sg = sendgrid.SendGridAPIClient(api_key=settings.SENDGRID_API_KEY)

    if property_details:
        if property_details.property_manager:
            to_emails = property_details.property_manager.email
            property_manager_name = property_details.property_manager.full_name
            property_manager_email = property_details.property_manager.email
            property_manager_contact = property_details.property_manager.phone_number
        else:
            to_emails = property_details.company.user.email
            property_manager_name = property_details.company.user.full_name
            property_manager_email = property_details.company.user.email
            property_manager_contact = property_details.company.user.phone_number
    else:
        if application.unit_details.property_details.property_manager:
            property_manager_name = str(application.unit_details.property_details.property_manager.full_name)
            property_manager_email = str(application.unit_details.property_details.property_manager.email)
            property_manager_contact = str(application.unit_details.property_details.property_manager.phone_number)
        else:
            property_manager_name = str(application.unit_details.property_details.company.user.full_name)
            property_manager_email = str(application.unit_details.property_details.company.user.email)
            property_manager_contact = str(application.unit_details.property_details.company.user.phone_number)

    from_email = settings.SENDGRID_EMAIL
    to_emails = application.email

    if status == "Approved":
        subject = "Your Application Has Been Approved"
        message = "Congratulations! We are excited to move forward with you."
    elif status == "Rejected":
        subject = "Your Application Has Been Rejected"
        message = rejection_message
    elif status == "In Review":
        subject = "Application Submitted Successfully"
        message = "Your application has been submitted successfully."
    else:
        return False

    # Read and customize the HTML template
    with open('quickprops_admin/templates/application_status_update.html', 'r') as file:
        content = file.read()

    content = content.replace('{{name}}', application.full_name)
    content = content.replace('{{status}}', status.capitalize())
    content = content.replace('{{message}}', message)
    content = content.replace('{{property_name}}', application.unit_details.property_details.property_name)
    content = content.replace('{{property_address}}', application.property_address)
    content = content.replace('{{property_manager}}', property_manager_name)
    content = content.replace('{{property_manager_contact}}', property_manager_contact)
    content = content.replace('{{property_manager_email}}', property_manager_email)
    content = content.replace('{{application_date}}', str(application.application_date))

    # Create a Mail object
    mail = Mail(
        from_email=from_email,
        to_emails=to_emails,
        subject=subject,
        html_content=content
    )

    # Get a JSON-ready representation of the Mail object
    mail_json = mail.get()

    try:
        response = sg.client.mail.send.post(request_body=mail_json)
        if response.status_code == 202:
            return True
        else:
            return False
    except Exception as e:
        print(f"Error sending email: {e}")
        if hasattr(e, 'code'):
            print(f"Error code: {e.code}")
        if hasattr(e, 'body'):
            print(f"Error body: {e.body}")
        return False

def send_cancelled_application_status_email(application):
    sg = sendgrid.SendGridAPIClient(api_key=settings.SENDGRID_API_KEY)

    from_email = settings.SENDGRID_EMAIL
    to_emails = application.email

    subject = "Your Application Has Been Cancelled"

    # Read and customize the HTML template
    with open('quickprops_admin/templates/application_status_update.html', 'r') as file:
        content = file.read()

    content = content.replace('{{name}}', application.full_name)
    content = content.replace('{{status}}', application.status.capitalize())
    content = content.replace('{{message}}', application.rejection_message)
    content = content.replace('{{property_name}}', application.unit_details.property_details.property_name)
    content = content.replace('{{property_address}}', application.property_address)
    content = content.replace('{{property_manager}}', str(application.unit_details.property_details.property_manager.full_name))
    content = content.replace('{{property_manager_contact}}', str(application.unit_details.property_details.property_manager.phone_number))
    content = content.replace('{{property_manager_email}}', str(application.unit_details.property_details.property_manager.email))
    content = content.replace('{{application_date}}', str(application.application_date))

    # Create a Mail object
    mail = Mail(
        from_email=from_email,
        to_emails=to_emails,
        subject=subject,
        html_content=content
    )

    # Get a JSON-ready representation of the Mail object
    mail_json = mail.get()

    try:
        response = sg.client.mail.send.post(request_body=mail_json)
        if response.status_code == 202:
            return True
        else:
            print(response.headers)
            return False
    except Exception as e:
        print(f"Error sending email: {e}")
        if hasattr(e, 'code'):
            print(f"Error code: {e.code}")
        if hasattr(e, 'body'):
            print(f"Error body: {e.body}")
        return False

def send_property_manager_email(application, property_details):
    sg = sendgrid.SendGridAPIClient(api_key=settings.SENDGRID_API_KEY)

    from_email = settings.SENDGRID_EMAIL
    if property_details.property_manager:
        to_emails = property_details.property_manager.email
        property_manager = property_details.property_manager.full_name
    else:
        to_emails = property_details.company.user.email
        property_manager = property_details.company.user.full_name
    subject = f"New Application Received for {property_details.property_name}"

    # Read and customize the HTML template
    with open('quickprops_app/templates/send_property_manager_new_application.html', 'r') as file:
        content = file.read()

    content = content.replace('{{name}}', application.full_name)
    content = content.replace('{{email}}', application.email)
    content = content.replace('{{contact_number}}', application.mobile)
    content = content.replace('{{property_manager}}', property_manager)
    content = content.replace('{{property_name}}', property_details.property_name)
    content = content.replace('{{property_address}}', application.property_address)

    # Create a Mail object
    mail = Mail(
        from_email=from_email,
        to_emails=to_emails,
        subject=subject,
        html_content=content
    )

    # Get a JSON-ready representation of the Mail object
    mail_json = mail.get()

    try:
        response = sg.client.mail.send.post(request_body=mail_json)
        if response.status_code == 202:
            return True
        else:
            return False
    except Exception as e:
        print(f"Error sending email: {e}")
        if hasattr(e, 'code'):
            print(f"Error code: {e.code}")
        if hasattr(e, 'body'):
            print(f"Error body: {e.body}")
        return False

def generate_lease_agreement(application):
    # PandaDoc API URL
    url = "https://api.pandadoc.com/public/v1/documents"

    headers = {
        "Authorization": f"API-Key {settings.PANDADOC_API_KEY}",
        "Content-Type": "application/json"
        }

    pets_allowed = application.unit_details.pet_policy
    pets_status_value = "Allowed" if pets_allowed else "Not Allowed"

    moving_date = datetime.strptime(application.moving_date, "%Y-%m-%d").date()
    # Prepare payload with lease agreement details
    payload = {
        "name": "Lease Agreement",
        "template_uuid": "Whc5yU57krr4bzHEQ5yVA9", # settings.PANDADOC_TEMPLATE_ID,
        "tokens": [
            {
                "name": "Current_Date",
                "value": datetime.now().strftime("%d-%m-%Y")
            },
            {
                "name": "Tenant_Name",
                "value": application.full_name
            },
            {
                "name": "Tenant_Current_Address",
                "value": application.current_address
            },
            {
                "name": "Full_PropertyAddress",
                "value": application.property_address
            },
            {
                "name": "Unit_Type",
                "value": application.unit_details.unit_type
            },
            {
                "name": "Rental_StartDate",
                "value": str(application.moving_date)
            },
            {
                "name": "Rental_EndDate",
                "value": str(moving_date + timedelta(days=364))
            },
            {
                "name": "Rent",
                "value": str(application.unit_details.rent)
            },
            {
                "name": "Penalty_Amount",
                "value": "1500"
            },
            {
                "name": "Number_of_Days",
                "value": "2 days"
            },
            {
                "name": "Deposit",
                "value": str(application.unit_details.deposit)
            },
            {
                "name": "Pets_Status",
                "value": pets_status_value
            }
        ],
        "recipients": [
            {
                "email": application.email,
                "first_name": application.full_name,
                "role": "Tenant"
            }
        ]
    }
    # Send the request to PandaDoc API to create the document
    response = requests.post(url, headers=headers, json=payload)

    if response.status_code == 201:
        document = response.json()
        document_id = document.get('id')
        print(f"Document created with ID: {document_id}")

        # Poll for document status
        document_data = poll_document_status(document_id)
        if document_data:
            send_document_for_signature(document_id, application)
            application.lease_agreement_id = document_id
            application.save()
    else:
        print("Error creating PandaDoc document:", response.text)
        return None

def poll_document_status(document_id):
    url = f"https://api.pandadoc.com/public/v1/documents/{document_id}"
    headers = {
        "Authorization": f"API-Key 81f98b3d72276dabde1c9bff1d44bdc683db4814"
    }
    print()
    while True:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            document = response.json()
            status = document.get('status')
            print(f"Document Status: {status}")

            if status in ['document.draft', 'document.signing']:
                print("Document is ready for signing!")
                return True
            else:
                print("Document is still being processed. Checking again in 10 seconds...")
                time.sleep(5)
        else:
            print(f"Error checking document status: {response.text}")
            return False

def send_document_for_signature(document_id, application):
    # PandaDoc API URL to send the document for signature
    send_url = f"https://api.pandadoc.com/public/v1/documents/{document_id}/send"

    headers = {
        "Authorization": f"API-Key 81f98b3d72276dabde1c9bff1d44bdc683db4814",
        "Content-Type": "application/json"
    }

    # Payload to send the document for signature
    payload = {
        "recipients": [
            {
                "email": application.email,  # Replace with tenant's email
                "first_name": application.full_name,  # Replace with tenant's first name
                "role": "Tenant"
            }
        ]
    }

    # Send the request to PandaDoc API to send the document for signature
    response = requests.post(send_url, headers=headers, json=payload)

    if response.status_code == 200:
        print("Document sent for signature successfully.")
    else:
        print(f"Error sending document for signature: {response.text}")

def check_document_status(document_id):
    url = f"https://api.pandadoc.com/public/v1/documents/{document_id}"
    headers = {
        "Authorization": f"API-Key 81f98b3d72276dabde1c9bff1d44bdc683db4814",
    }

    while True:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            document = response.json()
            status = document.get('status')
            print(f"Document Status: {status}")

            # Check if the document is signed
            if status == 'document.signed':
                print("The tenant has signed the document.")
                return True
            elif status == 'document.uploaded':
                print("The document is uploaded but not signed yet.")
            else:
                print("Document status is:", status)
        else:
            print("Error checking document status:", response.text)

        # Wait for a few seconds before checking again
        time.sleep(5)  # Wait for 5 seconds before polling again

def send_payment_confirmation_to_tenant(payment_details, lease):
    sg = sendgrid.SendGridAPIClient(api_key=settings.SENDGRID_API_KEY)

    from_email = settings.SENDGRID_EMAIL
    to_emails = payment_details.email

    subject = "Rent Payment Confirmation"

    # Read and customize the HTML template
    with open('quickprops_app/templates/rent_payment_confirmation.html', 'r') as file:
        content = file.read()

    content = content.replace('{{tenant_name}}', payment_details.full_name)
    content = content.replace('{{payment_id}}', payment_details.payment_id)
    content = content.replace('{{payment_date}}', str(lease.payment_date))
    content = content.replace('{{amount_paid}}', str(payment_details.amount_gross))
    content = content.replace('{{property_name}}', lease.property_name)
    content = content.replace('{{property_address}}', lease.property_address)

    # Create a Mail object
    mail = Mail(
        from_email=from_email,
        to_emails=to_emails,
        subject=subject,
        html_content=content
    )

    # Get a JSON-ready representation of the Mail object
    mail_json = mail.get()

    try:
        response = sg.client.mail.send.post(request_body=mail_json)
        if response.status_code == 202:
            return True
        else:
            return False
    except Exception as e:
        print(f"Error sending status update email: {e}")
        if hasattr(e, 'code'):
            print(f"Error code: {e.code}")
        if hasattr(e, 'body'):
            print(f"Error body: {e.body}")
        return False

def send_payment_confirmation_to_property_manager(payment_details, tenant, property_manager):
    sg = sendgrid.SendGridAPIClient(api_key=settings.SENDGRID_API_KEY)

    from_email = settings.SENDGRID_EMAIL
    to_emails = property_manager.email

    subject = "Rent Payment Confirmation"
    message = f"Dear {property_manager.full_name},\n\nWe would like to inform you that a rent payment has been successfully processed for your property."

    # Read and customize the HTML template
    with open('quickprops_app/templates/property_manager_payment_confirmation.html', 'r') as file:
        content = file.read()

    # Replace placeholders with actual data
    content = content.replace('{{property_manager_name}}', property_manager.full_name)
    content = content.replace('{{tenant_name}}', tenant.full_name)
    content = content.replace('{{payment_id}}', payment_details.payment_id)
    content = content.replace('{{payment_date}}', str(payment_details.created_at))
    content = content.replace('{{amount_paid}}', str(payment_details.amount))
    content = content.replace('{{property_address}}', payment_details.lease_details.property_address)

    # Create a Mail object
    mail = Mail(
        from_email=from_email,
        to_emails=to_emails,
        subject=subject,
        html_content=content
    )

    # Get a JSON-ready representation of the Mail object
    mail_json = mail.get()

    try:
        response = sg.client.mail.send.post(request_body=mail_json)
        if response.status_code == 202:
            return True
        else:
            print(response.headers)
            return False
    except Exception as e:
        print(f"Error sending payment confirmation email: {e}")
        if hasattr(e, 'code'):
            print(f"Error code: {e.code}")
        if hasattr(e, 'body'):
            print(f"Error body: {e.body}")
        return False
