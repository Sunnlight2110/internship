from django.urls import path
from .views import *
from .application import *

urlpatterns = [
    path('customer/register', CustomerRegistrationView.as_view(), name='customer-register'),
    path('customer/resend-otp', CustomerResendOTPView.as_view(), name='customer-resend-otp'),
    path('customer/email-verify', CustomerOTPVerificationView.as_view(), name='customer-email-verify'),
    path('customer/login', CustomerLoginView.as_view(), name='customer-login'),
    path('customer/forgetpassword-mail', CustomerForgetPasswordSendMail.as_view(), name='customer-forgot-password-mail'),
    path('customer/forget-password', CustomerForgetPassword.as_view(), name='customer-forget-password'),
    path('customer/change-password', CustomerChangePassword.as_view(), name='customer-change-password'),
    path('customer/logout', CustomerLogoutAPI.as_view(), name='logout'),
    path('customer/get-profile', CustomerProfileAPI.as_view(), name='customer-get-profile'),
    path('customer/nearby_units', UnitsByLocationAPIView.as_view(), name='nearby-units'),
    path('customer/units/<int:unit_id>', UnitDetailAPIView.as_view(), name='unit-detail'),

    # Applications APIs
    path('customer/applications', ApplicationDetailAPIView.as_view(), name='application-create'),
    path('customer/applications/<int:unit_id>', ApplicationDetailAPIView.as_view(), name='application-detail'),
    path('customer/all_applications_list', ListAllApplicationDetailAPIView.as_view(), name='application-listing'),
    path('customer/supporting_documents', SupportingDocumentAPIView.as_view(), name='supporting-document'),
    path('customer/supporting_documents/<int:document_id>', SupportingDocumentAPIView.as_view(), name='document-delete'),

    # Lease API
    path('customer/lease_list', ListAllLeaseAPIView.as_view(), name='lease-listing'),

    # CMS APIS
    path('customer/cms_view/<int:pk>', CMSView.as_view(), name='cms-view'),

    # Payment Details APIs
    path('customer/payment', PaymentDetailsPIView.as_view(), name='payment-create'),
    path('customer/payment/<int:lease_id>', PaymentDetailsPIView.as_view(), name='payment-detail-view'),
]
