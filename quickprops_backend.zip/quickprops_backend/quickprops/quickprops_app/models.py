from django.contrib.auth.models import (
    AbstractBaseUser,
    BaseUserManager,
    PermissionsMixin,
    Group,
    Permission,
)
from django.db import models
from rest_framework_simplejwt.tokens import RefreshToken


class UserRole(models.Model):
    """
    This model represents the roles that a user can have in the system.
    Each role has a unique name.
    """
    role_name = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return str(self.role_name)

class Permission(models.Model):
    """
    This model represents the permissions associated with a user role.
    Each permission grants specific actions (create, view, edit, delete).
    """
    role = models.ForeignKey(UserRole, on_delete=models.CASCADE)
    resource_name = models.CharField(max_length=255)
    create = models.BooleanField(default=True)
    view = models.BooleanField(default=True)
    edit = models.BooleanField(default=True)
    delete = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.role.role_name} - {self.resource_name}"

class UserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        superuser_role = UserRole.objects.get(id=2)
        extra_fields.setdefault('user_role', superuser_role)
        return self.create_user(email, password, **extra_fields)

def get_default_user_role():
    return UserRole.objects.get(role_name='customer').id


class User(AbstractBaseUser, PermissionsMixin):
    full_name = models.CharField(max_length=255, null=True, blank=True)
    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=15, null=True, blank=True)
    user_role = models.ForeignKey(UserRole, on_delete=models.SET_NULL, null=True, blank=True)
    profile_picture = models.ImageField(upload_to='profile_pictures/', null=True, blank=True)
    otp_code = models.CharField(max_length=4, null=True, blank=True)
    is_otp_code_verified = models.BooleanField(default=False)
    otp_code_verified_at = models.DateTimeField(null=True, blank=True)
    otp_expiry_time = models.DateTimeField(null=True, blank=True)
    company_id = models.IntegerField(null=True, blank=True)
    address = models.CharField(max_length=255, null=True, blank=True)
    dob = models.DateField(null=True, blank=True)  # Date of Birth field
    gender = models.CharField(max_length=10, null=True, blank=True)

    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True, null=True, blank=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    objects = UserManager()

    groups = models.ManyToManyField(
        Group,
        related_name='quickprops_app_users',  # Change this to a unique name
        blank=True,
        help_text='The groups this user belongs to. A user will get all permissions granted to each of their groups.',
        verbose_name='groups'
    )

    user_permissions = models.ManyToManyField(
        Permission,
        related_name='quickprops_app_users',  # Change this to a unique name
        blank=True,
        help_text='Specific permissions for this user.',
        verbose_name='user permissions'
    )

    def __str__(self):
        return str(self.email)

    def tokens(self):
        refresh = RefreshToken.for_user(self)
        return {
            'refresh': str(refresh),
            'access': str(refresh.access_token)
        }

class UserToken(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='token')
    access_token = models.TextField(null=True, blank=True)
    refresh_token = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'Token for {self.user.email}'

class Company(models.Model):
    """
    This model represents a company entity.
    It stores information about the company.
    """
    name = models.CharField(max_length=255, null=True, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    company_logo = models.ImageField(upload_to='company_logo/', null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return str(self.name)

class Application(models.Model):
    """
    Represents a rental application containing detailed information about the applicant,
    their financial status, employment, and supporting documents. This model is used
    to track and manage rental applications for properties.
    """
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    unit_details = models.ForeignKey('quickprops_admin.Unit',
                                     on_delete=models.SET_NULL, null=True, blank=True)
    property_address = models.CharField(max_length=255, null=True, blank=True)
    full_name = models.CharField(max_length=255, null=True, blank=True)
    maiden_name = models.CharField(max_length=255, null=True, blank=True)
    identity_number = models.CharField(max_length=20, null=True, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    nationality = models.CharField(max_length=100, null=True, blank=True)
    current_address = models.CharField(max_length=255, null=True, blank=True)
    marital_status = models.CharField(max_length=50, null=True, blank=True)

    is_owns_current_property = models.BooleanField(default=True)
    rental_paid = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    rental_duration = models.CharField(max_length=100, null=True, blank=True)
    landlord_name = models.CharField(max_length=100, null=True, blank=True)
    landlord_contact = models.CharField(max_length=15, null=True, blank=True)

    # Applicant’s Contact Details
    work_contact = models.CharField(max_length=15, null=True, blank=True)
    mobile = models.CharField(max_length=15, null=True, blank=True)
    email = models.EmailField(null=True, blank=True)

    next_of_kin_name = models.CharField(max_length=100, null=True, blank=True)
    next_of_kin_mobile = models.CharField(max_length=15, null=True, blank=True)

    # Banking Details
    bank_name = models.CharField(max_length=100, null=True, blank=True)
    branch_code = models.CharField(max_length=10, null=True, blank=True)
    account_number = models.CharField(max_length=20, null=True, blank=True)
    account_type = models.CharField(max_length=50, null=True, blank=True)

    application_date = models.DateField(null=True, blank=True)

    # Employment Details
    is_self_employed = models.BooleanField(default=False)
    occupation = models.CharField(max_length=100, null=True, blank=True)
    current_employer = models.CharField(max_length=255, null=True, blank=True)
    employer_address = models.CharField(max_length=255, null=True, blank=True)
    period_of_employment = models.CharField(max_length=100, null=True, blank=True)
    gross_monthly_salary = models.DecimalField(max_digits=10, decimal_places=2,
                                               null=True, blank=True)
    salary_payment_date = models.CharField(max_length=50, null=True, blank=True)

    number_of_adults = models.CharField(max_length=255, null=True, blank=True)
    number_of_children = models.CharField(max_length=255, null=True, blank=True)

    basic_monthly_gross_income = models.DecimalField(max_digits=10, decimal_places=2,
                                                     null=True, blank=True)
    total_income = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    regular_periodic_allowances = models.DecimalField(max_digits=10, decimal_places=2,
                                                      null=True, blank=True)

    # fields for Expenditure
    cell_phone_account = models.CharField(max_length=50, null=True, blank=True)
    clothing_accounts = models.CharField(max_length=50, null=True, blank=True)
    dstv_account = models.CharField(max_length=50, null=True, blank=True)
    furniture_account = models.CharField(max_length=50, null=True, blank=True)
    groceries = models.CharField(max_length=50, null=True, blank=True)
    insurance_policies = models.CharField(max_length=50, null=True, blank=True)
    loans = models.CharField(max_length=50, null=True, blank=True)
    child_maintenance = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    medical_aid = models.CharField(max_length=50, null=True, blank=True)
    motor_vehicle_insurance = models.CharField(max_length=50, null=True, blank=True)
    motor_vehicle_instalment = models.CharField(max_length=50, null=True, blank=True)
    rent = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    savings = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    school_fees = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    transport_costs = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    water_and_electricity = models.DecimalField(max_digits=10, decimal_places=2,
                                                null=True, blank=True)
    other_expenses = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    total_expenditure = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    # Net Cash Flow
    net_cash_flow = models.DecimalField(max_digits=10, decimal_places=2,
                                        null=True, blank=True)
    deposit_amount_required = models.DecimalField(max_digits=10, decimal_places=2,
                                                  null=True, blank=True)
    total_expenditure_net_cash_flow = models.DecimalField(max_digits=10, decimal_places=2,
                                                          null=True, blank=True)

    certified_id_document = models.CharField(max_length=255, null=True, blank=True)
    proof_of_residential_address = models.CharField(max_length=255, null=True, blank=True)
    latest_payslip_3_months = models.CharField(max_length=255, null=True, blank=True)
    bank_statements_3_months = models.CharField(max_length=255, null=True, blank=True)
    tax_number_verification = models.CharField(max_length=255, null=True, blank=True)
    marriage_certificate = models.CharField(max_length=255, null=True, blank=True)
    employment_confirmation_letter = models.CharField(max_length=255, null=True, blank=True)
    certified_birth_certificates = models.CharField(max_length=255, null=True, blank=True)
    ck_documents_and_affidavit = models.CharField(max_length=255, null=True, blank=True)

    status = models.CharField(max_length=20, null=True, blank=True)
    rejection_message = models.TextField(null=True, blank=True)
    rejection_blocked_until = models.DateTimeField(null=True, blank=True)
    lease_agreement_id = models.CharField(max_length=255, null=True, blank=True)
    lease_agreement_documents = models.CharField(max_length=255, null=True, blank=True)
    moving_date = models.DateField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True, null=True, blank=True)

    def __str__(self):
        return str(self.full_name)


class SpousePartnerDetail(models.Model):
    """
    Represents the details of a spouse or partner associated with a rental application.

    This model captures both personal and financial information of the applicant's spouse
    or partner, along with their employment and expenditure details.
    """
    application_details = models.ForeignKey(Application, on_delete=models.CASCADE,
                                    null=True, blank=True, related_name="spouse_partner_details")

    # Spouse/Partner's Information
    full_name = models.CharField(max_length=255, null=True, blank=True)
    maiden_name = models.CharField(max_length=255, null=True, blank=True)
    identity_number = models.CharField(max_length=20, null=True, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    nationality = models.CharField(max_length=100, null=True, blank=True)

    # Spouse/Partner's Contact Details
    work_contact = models.CharField(max_length=15, null=True, blank=True)
    mobile = models.CharField(max_length=15, null=True, blank=True)
    email = models.EmailField(null=True, blank=True)

    # Does the spouse reside at the same address?
    resides_same_address = models.BooleanField(default=True)

    # Employment Details
    is_self_employed = models.BooleanField(default=False)  # True for Yes, False for No
    occupation = models.CharField(max_length=100, null=True, blank=True)
    current_employer = models.CharField(max_length=255, null=True, blank=True)
    employer_address = models.CharField(max_length=255, null=True, blank=True)
    period_of_employment = models.CharField(max_length=100, null=True, blank=True)
    gross_monthly_salary = models.DecimalField(max_digits=10, decimal_places=2,
                                               null=True, blank=True)
    net_monthly_salary = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    salary_payment_date = models.CharField(max_length=50, null=True, blank=True)

    regular_periodic_allowances = models.DecimalField(max_digits=10, decimal_places=2,
                                                      null=True, blank=True)

    # fields for Expenditure
    cell_phone_account = models.CharField(max_length=50, null=True, blank=True)
    clothing_accounts = models.CharField(max_length=50, null=True, blank=True)
    dstv_account = models.CharField(max_length=50, null=True, blank=True)
    furniture_account = models.CharField(max_length=50, null=True, blank=True)
    groceries = models.CharField(max_length=50, null=True, blank=True)
    insurance_policies = models.CharField(max_length=50, null=True, blank=True)
    loans = models.CharField(max_length=50, null=True, blank=True)
    child_maintenance = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    medical_aid = models.CharField(max_length=50, null=True, blank=True)
    motor_vehicle_insurance = models.CharField(max_length=50, null=True, blank=True)
    motor_vehicle_instalment = models.CharField(max_length=50, null=True, blank=True)
    savings = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    school_fees = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    transport_costs = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    water_and_electricity = models.DecimalField(max_digits=10, decimal_places=2,
                                                null=True, blank=True)
    other_expenses = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    total_expenditure = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    def __str__(self):
        return f"{self.full_name} - {self.identity_number}"

class VehicleDetails(models.Model):
    """
    This model stores the details of vehicles associated with an application.
    It includes the vehicle type, registration number, and timestamps for creation and updates.
    """
    application_details = models.ForeignKey(
        Application, on_delete=models.CASCADE, null=True, blank=True, related_name="vehicles")
    vehicle_type = models.CharField(max_length=255)
    vehicle_registration = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.vehicle_type} - {self.vehicle_registration}"

class SupportingDocument(models.Model):
    """
    Represents a document uploaded by a user to support their application or account.
    This model is used to store references to files uploaded by users.
    """
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    file = models.FileField(upload_to='documents', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class AgreementDocument(models.Model):
    """
    This model represents an agreement document.
    """
    file = models.FileField(upload_to='agreement_document', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Lease(models.Model):
    """
    This model stores the details of a lease agreement for a property.
    """
    application_details = models.ForeignKey(Application, on_delete=models.PROTECT,
                                            null=True, blank=True, related_name="lease")
    unit_details = models.ForeignKey('quickprops_admin.Unit', on_delete=models.SET_NULL,
                                     null=True, blank=True)
    applicant_name = models.CharField(max_length=255, null=True, blank=True)
    applicant_email = models.EmailField(null=True, blank=True)
    property_name = models.CharField(max_length=255, null=True, blank=True)
    property_address = models.CharField(max_length=255, null=True, blank=True)
    unit_no = models.CharField(max_length=255, null=True, blank=True)
    rent = models.CharField(max_length=255, null=True, blank=True)
    deposit = models.CharField(max_length=255, null=True, blank=True)
    rental_start_date = models.DateField(null=True, blank=True)
    rental_termination_date = models.DateField(null=True, blank=True)
    lease_status = models.CharField(max_length=20, null=True, blank=True)
    lease_agreement_documents = models.CharField(max_length=255, null=True, blank=True)
    payment_id = models.CharField(max_length=255, null=True, blank=True)
    payment_date = models.DateField(null=True, blank=True)
    image = models.ImageField(upload_to='lease_images/')
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True, null=True, blank=True)

class PaymentDetails(models.Model):
    """
    This model stores payment information related to a lease agreement.
    It contains details such as the payment ID, status, amounts, and payer's information.
    """
    lease_details = models.ForeignKey(Lease, on_delete=models.PROTECT, null=True,
                                      blank=True, related_name="payment")
    payment_id = models.CharField(max_length=255, null=True, blank=True)
    payment_status = models.CharField(max_length=50, null=True, blank=True)
    property_name = models.CharField(max_length=255, null=True, blank=True)
    item_description = models.TextField(blank=True, null=True)
    amount_gross = models.DecimalField(max_digits=10, decimal_places=2)
    amount_fee = models.DecimalField(max_digits=10, decimal_places=2)
    amount_net = models.DecimalField(max_digits=10, decimal_places=2)
    full_name = models.CharField(max_length=100, blank=True, null=True)
    email = models.EmailField(null=True, blank=True)
    merchant_id = models.CharField(max_length=255, blank=True, null=True)
    signature = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)

    def __str__(self):
        return f"{self.full_name} - {self.payment_status}"
