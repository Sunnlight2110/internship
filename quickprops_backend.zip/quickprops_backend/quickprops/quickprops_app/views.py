# Standard Library Imports
import os
from datetime import datetime, timedelta

# Django Imports
from django.contrib.auth import authenticate
from django.utils import timezone
from django.contrib.auth.hashers import make_password
from django.shortcuts import get_object_or_404
from django.conf import settings
from django.utils.timezone import now

# Third-party Imports
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from geopy.distance import geodesic

# Local Application Imports
from quickprops_admin.models import Unit, CMS
from quickprops_admin.serializers import (
    CompanySerializer,
    BlockSerializer,
    ShowUnitSerializer,
    ListPropertyDevelopmentSerializer,
    CMSSerializer,
)
from Utilities.utils import (
    generate_otp,
    send_email_otp,
    send_phone_otp,
    send_email_resend_otp,
    send_password_reset_otp,
    is_valid_email,
    validate_password,
)
from .models import User, UserToken, Application
from .serializers import (
    CustomerRegistrationSerializer,
    CustomerLoginSerializer,
    CustomerSerializer,
    PropertyDevelopmentSerializer,
    ApplicationSerializer,
)

class CustomerRegistrationView(APIView):
    """
    This view handles the registration of a new user.
    """
    def post(self, request):
        """
        Registers a new user. This includes validating the input fields, checking for an existing user,
        generating an OTP, and sending it via email and phone.
        """
        data = request.data

        # Set default user role
        data['user_role'] = 1

        # Validate required fields
        required_fields = {
            'full_name': 'Name is required.',
            'email': 'Email is required.',
            'phone_number': 'Phone Number is required',
            'password': 'Password is required.',
        }
        for field, message in required_fields.items():
            if not data.get(field) or data[field].strip() == "":
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': message}, status=status.HTTP_200_OK)

        # Check if a user with the same email already exists
        if User.objects.filter(email=data.get('email').lower()).exists():
            return Response(
                {
                    'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                    'message': 'User with this email already exists. Please try a new one.'
                },
                status=status.HTTP_200_OK
            )

        # Generate OTP
        data["otp_code"] = generate_otp(4)
        data["otp_expiry_time"] = datetime.now()+timedelta(seconds=300)

        serializer = CustomerRegistrationSerializer(data=data)
        if serializer.is_valid():
            user = serializer.save()
            otp_sent_email = send_email_otp(user, user.otp_code)
            otp_sent_phone = send_phone_otp(user.phone_number, user.otp_code)

            if otp_sent_email or (otp_sent_phone and otp_sent_phone.status_code == 201):
                return Response(
                    {
                        'status': status.HTTP_201_CREATED, 'result': "1",
                        'message': 'User registered successfully. Kindly check your email or mobile.'
                    },
                    status=status.HTTP_200_OK
                )
            else:
                # Delete the user if OTP sending fails
                user.delete()
                return Response({'status': status.HTTP_500_INTERNAL_SERVER_ERROR, 'result': "0",
                                 'message': 'Failed to send OTP.'}, status=status.HTTP_200_OK)

        error_messages = serializer.errors.get('non_field_errors', [])
        if error_messages:
            # Join the error messages into a single string
            error_message = " ".join(error_messages)
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': error_message}, status=status.HTTP_200_OK)

        if 'email' in serializer.errors:
            return Response({ 'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                            'message': serializer.errors['email'][0]},
                            status=status.HTTP_200_OK)

        # Return error response if user registration fails
        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'message': 'User registration failed.',
                         'errors': serializer.errors}, status=status.HTTP_200_OK)

class CustomerResendOTPView(APIView):
    """
    This view allows the user to request a resend of the OTP (One-Time Password).
    """
    def post(self, request):
        """
        Resends the OTP to the user's email and mobile number. The email is validated,
        and the OTP is regenerated and sent if the user exists. If any error occurs during
        the process, an appropriate message is returned.
        """
        email = request.data.get('email')

        # Validate the email field
        if not email:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Email is required.'}, status=status.HTTP_200_OK)

        # Check if email format is valid using regular expressions
        if not is_valid_email(email):
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Enter a valid email address.'},
                            status=status.HTTP_200_OK)
        email = email.lower()

        # Check if a user with the provided email exists
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Email id not found.'}, status=status.HTTP_200_OK)

        # Generate a new OTP code
        user.otp_code = generate_otp(4)
        user.otp_expiry_time = datetime.now()+timedelta(seconds=300)
        user.save()

        # Send the OTP via email and mobile
        otp_sent_email = send_email_resend_otp(user, user.otp_code)
        otp_sent_phone = send_phone_otp(user.phone_number, user.otp_code)

        if otp_sent_email or (otp_sent_phone and otp_sent_phone.status_code == 201):
            return Response({'status': status.HTTP_201_CREATED, 'result': "1",
                             'message': 'OTP has been resent. Kindly check your email or mobile.'},
                            status=status.HTTP_200_OK)
        else:
            return Response({'status': status.HTTP_500_INTERNAL_SERVER_ERROR, 'result': "0",
                             'message': 'Failed to send OTP.'}, status=status.HTTP_200_OK)

class CustomerOTPVerificationView(APIView):
    """
    This view handles the OTP verification process for a user.
    """

    def post(self, request):
        """
        Verifies the OTP provided by the user. The email and OTP are validated,
        and if the OTP is correct and not expired, the user is marked as verified.
        """
        data = request.data
        email = data.get('email')
        otp = data.get('otp')

        # Check if email and OTP are provided
        if not email:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Email is required.'}, status=status.HTTP_200_OK)
        if not otp:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'OTP is required.'}, status=status.HTTP_200_OK)

        # Check if email format is valid using regular expressions
        if not is_valid_email(email):
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Enter a valid email address.'},
                            status=status.HTTP_200_OK)
        email = email.lower()
        try:
            # Find the user with the provided email
            user = User.objects.get(email=email)
            current_otp_time = timezone.now()

            if current_otp_time < user.otp_expiry_time:

                # Check if the OTP matches
                if user.otp_code == otp:
                    # Mark email as verified
                    user.is_otp_code_verified = True
                    user.otp_code_verified_at = timezone.now()
                    user.save()
                    return Response({'status': status.HTTP_200_OK, 'result': "1",
                                    'message': 'OTP verified successfully.'},
                                    status=status.HTTP_200_OK)
                else:
                    return Response({'status': status.HTTP_403_FORBIDDEN, 'result': "0",
                                    'message': 'Invalid OTP.'}, status=status.HTTP_200_OK)
            else:
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': 'OTP expired.'}, status=status.HTTP_200_OK)

        except User.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Email id not found.'}, status=status.HTTP_200_OK)

class CustomerLoginView(APIView):
    """
    This view handles the login functionality for users. It authenticates the user based on
    the provided email and password, verifies if the user’s account is active and OTP verified,
    and returns a JWT access token if the login is successful.
    """
    def post(self, request):
        """
        Authenticates the user with the provided email and password. If the credentials are valid,
        the user is logged in, and a JWT token is returned. If the user’s email is not verified,
        an OTP is sent to the user's email and mobile.
        """
        data = request.data

        # Check if email is provided
        if not data.get('email') or data['email'].strip() == "":
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Email is required.'}, status=status.HTTP_200_OK)

        # Check if password is provided
        if not data.get('password') or data['password'].strip() == "":
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Password is required.'}, status=status.HTTP_200_OK)

        serializer = CustomerLoginSerializer(data=data)
        if serializer.is_valid():
            email = serializer.data['email'].lower()
            password = serializer.validated_data['password']

            # Check if the user exists with the provided email
            try:
                user = User.objects.get(email=email)
            except User.DoesNotExist:
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': "Email id not found."}, status=status.HTTP_200_OK)

            # Check if the user is active
            if not user.is_active:
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': 'Account is inactive.'}, status=status.HTTP_200_OK)

            # Check if the user_role is 1
            if user.user_role.id != 1:
                return Response({'status': status.HTTP_401_UNAUTHORIZED, 'result': "0",
                                 'message': 'Only tenant are allowed to log in.'},
                                status=status.HTTP_200_OK)

            # Authenticate the user with the provided credentials
            user = authenticate(email=email, password=password)

            if user is not None:
                # Check if email is verified
                if not user.is_otp_code_verified:
                    user.otp_code = generate_otp(4)
                    user.otp_expiry_time = datetime.now()+timedelta(seconds=300)
                    user.last_login = timezone.now()
                    user.save()
                    otp_sent_email = send_email_resend_otp(user, user.otp_code)
                    otp_sent_phone = send_phone_otp(user.phone_number, user.otp_code)

                    if otp_sent_email or (otp_sent_phone and otp_sent_phone.status_code == 201):
                        refresh = RefreshToken.for_user(user)
                        access_token = str(refresh.access_token)

                        user_token, created = UserToken.objects.get_or_create(user=user)
                        user_token.access_token = access_token
                        user_token.save()
                        return Response(
                            {
                                'status': status.HTTP_403_FORBIDDEN, 'result': "0",
                                'message': 'Email not verified. An OTP has been sent to your email and mobile. Please verify your email.',
                                'data':
                                    {
                                        'user_role': user.user_role.id,
                                        'otp_verify': user.is_otp_code_verified,
                                        'access': str(refresh.access_token),
                                        'refresh': str(refresh)
                                    }
                            },
                            status=status.HTTP_200_OK
                        )

                # Generate JWT tokens for the authenticated user
                refresh = RefreshToken.for_user(user)
                access_token = str(refresh.access_token)

                user_token, created = UserToken.objects.get_or_create(user=user)
                user_token.access_token = access_token
                user_token.save()
                user.last_login = timezone.now()
                user.save()
                return Response({'status': status.HTTP_200_OK, 'result': "1",
                                 'message': 'Login successful',
                                 'data': {
                                     'user_role': user.user_role.id,
                                     'access': str(refresh.access_token),
                                     'refresh': str(refresh)
                                     }},
                                status=status.HTTP_200_OK)
            else:
                return Response({'status': status.HTTP_401_UNAUTHORIZED, 'result': "0",
                                 'message': 'Invalid password'}, status=status.HTTP_200_OK)
        if 'email' in serializer.errors:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': serializer.errors['email'][0]},
                            status=status.HTTP_200_OK)

        # Return validation errors if the serializer is not valid
        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'message': 'Invalid data', 'errors': serializer.errors},
                        status=status.HTTP_200_OK)

class CustomerLogoutAPI(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user  # Get the logged-in user
        try:
            # Try to get the UserToken associated with the user
            user_token = UserToken.objects.get(user=user)

            # Delete the token
            user_token.delete()
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': "Logout successful"}, status=status.HTTP_200_OK)

        except UserToken.DoesNotExist:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': "User is already logged out or token not found"},
                            status=status.HTTP_200_OK)

class CustomerForgetPasswordSendMail(APIView):
    """
    This view handles the process of sending a password reset OTP to the user's email and phone number.
    """
    def post(self, request):
        """
        This method processes the request to send a password reset OTP to the provided email and phone number.
        It validates the email, checks user existence, verifies account status, generates an OTP,
        and sends the OTP to the user via email and SMS.
        """
        try:
            # Get the email from the request data
            email = request.data.get('email')

            # Validate if email is provided
            if not email:
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': 'Email is required.'}, status=status.HTTP_200_OK)

            # Check if email format is valid using regular expressions
            if not is_valid_email(email):
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                'message': 'Enter a valid email address.'},
                                status=status.HTTP_200_OK)
            email = email.lower()
            # Check if the user with the provided email exists
            if User.objects.filter(email=email).exists():
                user = User.objects.get(email=email)

                # Check if the user's account is active
                if not user.is_active:
                    return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                                     'message': 'Account is inactive.'}, status=status.HTTP_200_OK)

                # Check if the user_role is 1
                if user.user_role.id != 1:
                    return Response({'status': status.HTTP_401_UNAUTHORIZED, 'result': "0",
                                    'message': 'Only tenant are allowed to forget password.'},
                                    status=status.HTTP_200_OK)

                # Generate and save OTP for password reset
                otp_code = generate_otp(4)
                user.otp_code = otp_code
                user.otp_expiry_time = datetime.now()+timedelta(seconds=300)
                user.save()

                otp_sent_email = send_password_reset_otp(user, otp_code)
                otp_sent_phone = send_phone_otp(user.phone_number, otp_code)

                if otp_sent_email or (otp_sent_phone and otp_sent_phone.status_code == 201):
                    return Response(
                        {
                            'status': status.HTTP_200_OK, 'result': "1",
                            'message': 'Please check your email and mobile for the password reset.'
                        },
                        status=status.HTTP_200_OK
                    )
                else:
                    return Response({'status': status.HTTP_500_INTERNAL_SERVER_ERROR, 'result': "0",
                                     'message': 'Failed to send OTP.'}, status=status.HTTP_200_OK)
            else:
                # If user does not exist, return an error response
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': 'Email id not found.'}, status=status.HTTP_200_OK)

        except Exception as e:
            # Handle any exceptions and return an error response
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': str(e)}, status=status.HTTP_200_OK)

class CustomerForgetPassword(APIView):
    """
    This view handles the process of resetting a user's password.
    It validates the email and new password, checks if the user exists,
    and ensures that OTP verification is done before resetting the password.
    """
    def post(self, request):
        """
        This method processes the request to reset the user's password.
        It validates the email and new password, checks if the OTP code
        is verified, and then resets the user's password if all conditions are met.
        """
        data = request.data
        email = data.get('email')
        new_password = data.get('new_password')

        # Validate required fields
        required_fields = {
            'email': 'Email is required.',
            'new_password': 'New password are required.',
        }
        for field, message in required_fields.items():
            if not data.get(field) or data[field].strip() == "":
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': message}, status=status.HTTP_200_OK)

        # Check if email format is valid using regular expressions
        if not is_valid_email(email):
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Enter a valid email address.'},
                            status=status.HTTP_200_OK)
        email = email.lower()
        # Validate the new password
        password_validation_error = validate_password(new_password)
        if password_validation_error:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': password_validation_error}, status=status.HTTP_200_OK)
        try:
            # Find the user with the provided email
            user = User.objects.get(email=email)
            if user.is_otp_code_verified:
                user.password = make_password(new_password)
                user.save()
                return Response({'status': status.HTTP_200_OK, 'result': "1",
                                 'message': 'Password has been reset successfully.'},
                                status=status.HTTP_200_OK)
            else:
                # If OTP is not verified, return an error message
                return Response({'status': status.HTTP_403_FORBIDDEN, 'result': "0",
                                 'message': 'OTP verification required before resetting password.'},
                                status=status.HTTP_200_OK)

        except User.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Email not found.'}, status=status.HTTP_200_OK)

class CustomerChangePassword(APIView):
    """
    This view allows an authenticated user to change their password.
    It requires the current (old) password and the new password.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        """
        Handles the request to change the user's password.
        Validates the current password, ensures the new password is different,
        and updates the password if the validation passes.
        """
        data = request.data
        user = request.user
        old_password = data.get('old_password')
        new_password = data.get('new_password')

        required_fields = {
            'old_password': 'Current Password is required.',
            'new_password': 'New password is required.',
        }
        for field, message in required_fields.items():
            if not data.get(field) or data[field].strip() == "":
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': message}, status=status.HTTP_200_OK)

        # Authenticate the user with old password
        user = authenticate(email=user.email, password=old_password)

        if user is None:
            return Response({'status': status.HTTP_403_FORBIDDEN, 'result': "0",
                             'message': 'Current password is incorrect.'},
                            status=status.HTTP_200_OK)

        # Check if new password is the same as old password
        if old_password == new_password:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'New password must be different from current password.'},
                            status=status.HTTP_200_OK)

        # Set the new password
        user.set_password(new_password)
        user.save()

        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'message': 'Password changed successfully.'},
                        status=status.HTTP_200_OK)

class CustomerProfileAPI(APIView):
    """
    This view handles the retrieval and update of customer profile information.
    Only authenticated users can access and modify their profile.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        """
        Fetches the profile data of the currently authenticated user.
        """
        try:
            # Fetch user object based on the logged-in user's ID
            user = get_object_or_404(User, id=request.user.id)

            # Serialize the user data
            serializer = CustomerSerializer(user)

            # Return the user data in the response
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'data': serializer.data}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': str(e)}, status=status.HTTP_200_OK)

    def patch(self, request, *args, **kwargs):
        """
        Updates the profile information of the currently authenticated user.
        """
        try:
            data = request.data

            # Check if a user with the same email already exists (except for the current user)
            if 'email' in request.data and User.objects.filter(email=request.data['email'].lower()
                                                               ).exclude(id=request.user.id).exists():
                return Response(
                    {
                        'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                        'message': 'User with this email already exists. Please try a new one.'
                    },
                    status=status.HTTP_200_OK
                )

            # Fetch the user object
            user = get_object_or_404(User, id=request.user.id)

            # Partial update user data
            serializer = CustomerSerializer(user, data=data, partial=True)

            if serializer.is_valid():
                new_profile_picture = request.FILES.get('profile_picture')
                if new_profile_picture and user.profile_picture:
                    # Delete the old profile picture
                    old_picture_path = user.profile_picture.path
                    if os.path.exists(old_picture_path):
                        os.remove(old_picture_path)
                serializer.save()
                return Response({'status': status.HTTP_200_OK, 'result': "1",
                                 'message': 'Profile updated successfully',
                                 'data': serializer.data}, status=status.HTTP_200_OK)

            error_messages = serializer.errors.get('non_field_errors', [])
            if error_messages:
                # Join the error messages into a single string
                error_message = " ".join(error_messages)
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': error_message}, status=status.HTTP_200_OK)

            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Invalid data', 'errors': serializer.errors},
                            status=status.HTTP_200_OK)

        except Exception as e:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': str(e)}, status=status.HTTP_200_OK)

class UnitsByLocationAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        latitude = request.data.get('latitude')
        longitude = request.data.get('longitude')
        radius = request.data.get('radius', 5)
        unit_type = request.data.get('unit_type')
        min_rent = request.data.get('min_rent')  # Minimum rent
        max_rent = request.data.get('max_rent')  # Maximum rent
        furnishing_status = request.data.get('furnishing_status')
        number_of_bedrooms = request.data.get('number_of_bedrooms')
        number_of_bathrooms = request.data.get('number_of_bathrooms')
        parking_spaces = request.data.get('parking_spaces')
        pet_policy = request.data.get('pet_policy')
        available_from = request.data.get('available_from')
        page = request.data.get('page', 1)
        items_per_page = request.data.get('items_per_page', 10)

        if latitude is None or longitude is None:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Latitude and Longitude are required.'},
                            status=status.HTTP_200_OK)
        user = request.user

        units = Unit.objects.filter(
            property_details__latitude__isnull=False,
            property_details__longitude__isnull=False,
            property_details__property_status=True,
            is_vacant=True).exclude(is_deleted=True).order_by('-id')

        # Exclude units with active blocks based on applications
        blocked_unit_ids = Application.objects.filter(
            rejection_blocked_until__gt=now(),
            user=user).values_list('unit_details__id', flat=True)

        units = units.exclude(id__in=blocked_unit_ids)

        if unit_type:
            units = units.filter(unit_type=unit_type)
        if min_rent is not None:
            units = units.filter(rent__gte=min_rent)  # Greater than or equal to min_rent
        if max_rent is not None:
            units = units.filter(rent__lte=max_rent)  # Less than or equal to max_rent
        if furnishing_status is not None:
            units = units.filter(furnishing_status=furnishing_status)
        if number_of_bedrooms is not None:
            units = units.filter(number_of_bedrooms__gte=number_of_bedrooms)
        if number_of_bathrooms is not None:
            units = units.filter(number_of_bathrooms__gte=number_of_bathrooms)
        if parking_spaces is not None:
            units = units.filter(parking_spaces__gte=parking_spaces)
        if pet_policy is not None:
            units = units.filter(pet_policy=pet_policy)
        if available_from:
            units = units.filter(available_from__gte=available_from)

        nearby_units = []

        for unit in units:
            unit_location = (unit.property_details.latitude, unit.property_details.longitude)
            user_location = (latitude, longitude)
            distance = geodesic(user_location, unit_location).kilometers

            if distance <= radius:
                nearby_units.append(unit)

        # Manually paginate the results
        start = (page - 1) * items_per_page
        end = start + items_per_page
        paginated_units = nearby_units[start:end]

        # Format the response to include only the required fields
        response = []
        for unit in paginated_units:
            property_serializer = PropertyDevelopmentSerializer(unit.property_details)

            # Fetching images for the property
            images = unit.property_details.images.all()  # Assuming the property has related images
            image_urls = [
                f"http://{settings.IMAGE_HOST}:{settings.IMAGE_PORT}{image.image.url}"
                for image in images
            ]
            response.append({
                "unit_id": unit.id,
                "unit": unit.unit_no,
                "unit_type": unit.unit_type,
                "block": unit.block_details.block_name if unit.block_details else "",
                "property_type": property_serializer.data['property_type'],
                "property_name": property_serializer.data['property_name'],
                "address": property_serializer.data['address'],
                "rent": str(unit.rent),
                "available_from": unit.available_from,
                "number_of_bedrooms": unit.number_of_bedrooms,
                "number_of_bathrooms": unit.number_of_bathrooms,
                "parking_spaces": unit.parking_spaces,
                "furnishing_status": unit.furnishing_status,
                "pet_policy": unit.pet_policy,
                "is_vacant": unit.is_vacant,
                "images": image_urls
            })
        total_units = len(nearby_units)  # Total number of units for pagination
        total_pages = (total_units // items_per_page) + (
            1 if total_units % items_per_page > 0 else 0)

        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'message': 'Successfully fetched units.',
                         'data': response, 'total_pages': total_pages},
                        status=status.HTTP_200_OK)

class UnitDetailAPIView(APIView):
    """
    This API handles the retrieval of entity details, including view-related properties.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request, unit_id):
        try:
            # Fetch the unit object based on the provided unit_id
            unit = Unit.objects.get(id=unit_id)

            application = Application.objects.filter(
                user=request.user, unit_details=unit).exclude(status="Rejected").first()
            if application:
                application_serializer = ApplicationSerializer(application)
                serialized_data = application_serializer.data
                application_status = serialized_data['status']
            else:
                application_status = ''

            unit_serializer = ShowUnitSerializer(unit)

            # Get associated property details and serialize if exists
            property_details = unit.property_details
            property_serializer = ListPropertyDevelopmentSerializer(property_details) if property_details else None

            # Get associated block details and serialize if exists
            block_details = unit.block_details
            block_serializer = BlockSerializer(block_details) if block_details else None

            company = property_details.company if property_details else None
            company_serializer = CompanySerializer(company) if company else None

            if property_details.property_manager:
                property_manager = property_details.property_manager if property_details else None
                company_user_serializer = CustomerSerializer(property_manager) if property_manager else None
            else:
                company_user = company.user if company else None
                company_user_serializer = CustomerSerializer(company_user) if company_user else None

            # Response format
            response_data = {
                "unit_details": unit_serializer.data,
                "property_details": property_serializer.data if property_serializer else {},
                "block_details": block_serializer.data if block_serializer else None,
                "company_details": {
                    **company_serializer.data,
                    "user_details": company_user_serializer.data if company_user_serializer else {}
                } if company_serializer else {},
                "application_status": application_status,
            }
            # Format image URLs for unit details
            if "images" in response_data["unit_details"]:
                for image in response_data["unit_details"]["images"]:
                    image['image'] = f"http://{settings.IMAGE_HOST}:{settings.IMAGE_PORT}{image['image']}"

            # Format image URLs for property details if available
            if property_serializer and "images" in response_data["property_details"]:
                for image in response_data["property_details"]["images"]:
                    image['image'] = f"http://{settings.IMAGE_HOST}:{settings.IMAGE_PORT}{image['image']}"

            if 'security_features' in response_data["property_details"]:
                security_features = response_data["property_details"]['security_features']
                if isinstance(security_features, list):
                    security_features = [
                        feature for feature in security_features if feature.strip()
                        ]
                    response_data["property_details"]['security_features'] = security_features

            if 'nearby_transport' in response_data["property_details"]:
                nearby_transport = response_data["property_details"]['nearby_transport']
                if isinstance(nearby_transport, list):
                    nearby_transport = [feature for feature in nearby_transport if feature.strip()]
                    response_data["property_details"]['nearby_transport'] = nearby_transport

            if 'additional_amenities' in response_data["unit_details"]:
                nearby_transport = response_data["unit_details"]['additional_amenities']
                if isinstance(nearby_transport, list):
                    nearby_transport = [feature for feature in nearby_transport if feature.strip()]
                    response_data["unit_details"]['additional_amenities'] = nearby_transport

            if response_data.get("block_details"):
                if 'common_area_features' in response_data["block_details"]:
                    common_area_features = response_data["block_details"]['common_area_features']
                    if isinstance(common_area_features, list):
                        common_area_features = [
                            feature for feature in common_area_features if feature.strip()
                            ]
                        response_data["block_details"]['common_area_features'] = common_area_features

            if 'unit_security_features' in response_data["unit_details"]:
                unit_security_features = response_data["unit_details"]['unit_security_features']
                if isinstance(unit_security_features, list):
                    unit_security_features = [
                        feature for feature in unit_security_features if feature.strip()
                        ]
                    response_data["unit_details"]['unit_security_features'] = unit_security_features

            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'Successfully', 'data': response_data},
                            status=status.HTTP_200_OK)

        except Unit.DoesNotExist:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Unit not found.'}, status=status.HTTP_200_OK)

class CMSView(APIView):
    """
    This view handles the retrieval of CMS content.
    """
    def get(self, request, pk=None):
        """
        Fetches CMS content based on the provided pk.
        If pk is not provided, all CMS instances are fetched.
        """
        if pk:
            cms_instance = get_object_or_404(CMS, pk=pk)
            serializer = CMSSerializer(cms_instance)
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': "Successfully fetched CMS.",
                             'data': serializer.data}, status=status.HTTP_200_OK)
        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'message': "No CMS content available, pk is required.",
                         'data': None}, status=status.HTTP_400_BAD_REQUEST)
