# Django Imports
from django.conf import settings

# Third-party Imports
from rest_framework import serializers

# Local Application Imports
from .models import (
    User,
    Application,
    SpousePartnerDetail,
    VehicleDetails,
    SupportingDocument,
    Lease,
    PaymentDetails
)
from quickprops_admin.models import PropertyDevelopment
from quickprops_admin.serializers import *


class CustomerRegistrationSerializer(serializers.ModelSerializer):

    class Meta:
        model = User
        fields = ['full_name', 'email', 'phone_number', 'password', 'user_role',
                  'otp_code', 'otp_expiry_time']

    def validate(self, data):
        password = data['password']
        phone_number = data['phone_number']

        # Convert email to lowercase
        data['email'] = data['email'].lower()

        # Check password length
        if len(password) < 8:
            raise serializers.ValidationError("Password must be at least 8 characters long.")

        # Check for at least one numeric digit
        if not any(char.isdigit() for char in password):
            raise serializers.ValidationError("Password must contain at least one numeric digit.")

        # Check for at least one letter
        if not any(char.isalpha() for char in password):
            raise serializers.ValidationError("Password must contain at least one letter.")

        # Check for at least one lowercase letter
        if not any(char.islower() for char in password):
            raise serializers.ValidationError("Password must contain at least one lowercase letter.")

        # Check for at least one uppercase letter
        if not any(char.isupper() for char in password):
            raise serializers.ValidationError("Password must contain at least one uppercase letter.")

        # Check for at least one special character
        if not any(char in '!@#$%^&*()_+-=[]{}|;:,.<>?/' for char in password):
            raise serializers.ValidationError("Password must contain at least one special character.")

        # Check if phone number already exists
        if User.objects.filter(phone_number=phone_number).exists():
            raise serializers.ValidationError("This phone number is already in use. Please use a different one.")

        # Check if phone number is numeric
        if not phone_number.isdigit():
            raise serializers.ValidationError("Phone number must contain only digits.")

        # Check length of phone number (10 digits)
        if len(phone_number) < 9 or len(phone_number) > 12:
            raise serializers.ValidationError("Phone number must be between 9 and 12 digits long.")
        return data

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        return user

class CustomerLoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField()

class CustomerSerializer(serializers.ModelSerializer):
    user_role = serializers.SerializerMethodField()
    class Meta:
        model = User
        fields = ['id', 'full_name', 'email', 'phone_number', 'profile_picture',
                  'address', 'dob', 'gender', 'user_role', 'is_active',
                  'created_at', 'updated_at']


    def validate(self, data):
        phone_number = data.get('phone_number')
        user_id = self.instance.id if self.instance else None  # Get the ID of the current user

        if phone_number is not None:

            # Check if phone number already exists
            if User.objects.filter(phone_number=phone_number).exclude(id=user_id).exists():
                raise serializers.ValidationError("This phone number is already in use. Please use a different one.")

            # Check if phone number is numeric
            if not phone_number.isdigit():
                raise serializers.ValidationError("Phone number must contain only digits.")

            # Check length of phone number (10 digits)
            if len(phone_number) < 9 or len(phone_number) > 12:
                raise serializers.ValidationError("Phone number must be between 9 and 12 digits long.")

        return data

    def get_user_role(self, obj):
        return obj.user_role.role_name if obj.user_role else None

    def to_representation(self, instance):
        # Get the original representation
        representation = super().to_representation(instance)

        # Construct the full URL for the profile picture
        if instance.profile_picture:
            representation['profile_picture'] = f"http://{settings.IMAGE_HOST}:{settings.IMAGE_PORT}{instance.profile_picture.url}"

        return representation

class PropertyDevelopmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = PropertyDevelopment
        fields = ['property_name', 'property_type', 'address']

class SpousePartnerDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = SpousePartnerDetail
        fields = '__all__'

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        for key, value in representation.items():
            if value is None:
                representation[key] = ""  # Change None to empty string

        return representation

class VehicleDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = VehicleDetails
        fields = ['vehicle_type', 'vehicle_registration']

class ApplicationSerializer(serializers.ModelSerializer):
    spouse_partner_details = SpousePartnerDetailSerializer(required=False,  allow_null=True)
    vehicles = VehicleDetailsSerializer(many=True, required=False, allow_null=True)
    property_id = serializers.CharField(source='unit_details.property_details.id', read_only=True)
    property_name = serializers.CharField(source='unit_details.property_details.property_name', read_only=True)
    available_from = serializers.CharField(source='unit_details.available_from', read_only=True)
    unit_type = serializers.CharField(source='unit_details.unit_type', read_only=True)
    class Meta:
        model = Application
        fields = '__all__'

    def create(self, validated_data):
        # Remove spouse data from validated_data
        spouse_data = validated_data.pop('spouse_partner_details', None)

        # Create Application instance
        application = Application.objects.create(**validated_data)

        # Create SpousePartnerDetail if spouse_data is present
        if spouse_data:
            # Associate the application instance with spouse data
            SpousePartnerDetail.objects.create(application_details=application, **spouse_data)

        return application

    def update(self, instance, validated_data):
        # Update Application instance fields
        vehicles_data = validated_data.pop('vehicles', None)
        spouse_data = validated_data.pop('spouse_partner_details', None)

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        if spouse_data is None:
            SpousePartnerDetail.objects.filter(application_details=instance).delete()

        # Update SpousePartnerDetail if spouse data is present
        if spouse_data:
            spouse_partner_detail, created = SpousePartnerDetail.objects.get_or_create(application_details=instance)
            for attr, value in spouse_data.items():
                setattr(spouse_partner_detail, attr, value)
            spouse_partner_detail.save()

        if vehicles_data is not None:
            instance.vehicles.all().delete()
            for vehicle_data in vehicles_data:
                VehicleDetails.objects.create(application_details=instance, **vehicle_data)

        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        spouse_partner_detail = SpousePartnerDetail.objects.filter(application_details=instance).first()
        if spouse_partner_detail:
            representation['spouse_partner_details'] = SpousePartnerDetailSerializer(spouse_partner_detail).data
        else:
            representation['spouse_partner_details'] = None

        # Get all associated vehicle details

        vehicles = VehicleDetails.objects.filter(application_details=instance)
        if vehicles:
            representation['vehicles'] = VehicleDetailsSerializer(vehicles, many=True).data
        else:
            representation['vehicles'] = None

        # Construct the full URL for the profile picture
        if instance.lease_agreement_documents:
            representation['lease_agreement_documents'] = f"http://{settings.IMAGE_HOST}:{settings.IMAGE_PORT}/media/{instance.lease_agreement_documents}"
        return representation

class ApplicationListingSerializer(serializers.ModelSerializer):
    unit_id = serializers.IntegerField(source='unit_details.id', read_only=True)
    property_name = serializers.CharField(source='unit_details.property_details.property_name', read_only=True)
    property_address = serializers.CharField(source='unit_details.property_details.address', read_only=True)
    block_name = serializers.CharField(source='unit_details.block_details.block_name', read_only=True)  # Add block name
    unit_no = serializers.IntegerField(source='unit_details.unit_no', read_only=True)
    rent = serializers.DecimalField(source='unit_details.rent', max_digits=10, decimal_places=2, read_only=True)
    deposit = serializers.DecimalField(source='unit_details.deposit', max_digits=10, decimal_places=2, read_only=True)
    available_from = serializers.DateField(source='unit_details.available_from', read_only=True)
    parking_spaces = serializers.IntegerField(source='unit_details.parking_spaces', read_only=True)
    class Meta:
        model = Application
        fields = ['id', 'user', 'unit_id', 'property_name', 'property_address', 'block_name',
                  'unit_no', 'rent', 'deposit', 'available_from', 'parking_spaces', 'status',
                  'rejection_message', 'lease_agreement_documents']

    def to_representation(self, instance):
        # Get the original representation
        representation = super().to_representation(instance)

        # Construct the full URL for the profile picture
        if instance.lease_agreement_documents:
            representation['lease_agreement_documents'] = f"http://{settings.IMAGE_HOST}:{settings.IMAGE_PORT}/media/{instance.lease_agreement_documents}"

        return representation

class SupportingDocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = SupportingDocument
        fields = ['id', 'file']

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        if instance.file:
            representation['file'] = f"http://{settings.IMAGE_HOST}:{settings.IMAGE_PORT}{instance.file.url}"

        return representation

class LeaseListingSerializer(serializers.ModelSerializer):
    unit_id = serializers.IntegerField(source='unit_details.id', read_only=True)
    property_name = serializers.CharField(source='unit_details.property_details.property_name', read_only=True)
    property_address = serializers.CharField(source='unit_details.property_details.address', read_only=True)
    unit_no = serializers.IntegerField(source='unit_details.unit_no', read_only=True)
    rent = serializers.DecimalField(source='unit_details.rent', max_digits=10, decimal_places=2, read_only=True)
    deposit = serializers.DecimalField(source='unit_details.deposit', max_digits=10, decimal_places=2, read_only=True)
    available_from = serializers.DateField(source='unit_details.available_from', read_only=True)
    class Meta:
        model = Application
        fields = ['id', 'user', 'unit_id', 'property_name', 'property_address',
                  'unit_no', 'rent', 'deposit', 'available_from']

class LeaseSerializer(serializers.ModelSerializer):
    property_id = serializers.CharField(source='unit_details.property_details.id', read_only=True)
    unit_type = serializers.CharField(source='unit_details.unit_type', read_only=True)

    class Meta:
        model = Lease
        fields = [
            'id', 'property_id', 'unit_type', 'applicant_name', 'applicant_email',
            'application_details', 'unit_details', 'property_name', 'property_address',
            'unit_no', 'rent', 'deposit', 'rental_start_date', 'rental_termination_date',
            'lease_status', 'payment_id', 'payment_date', 'image',
            'lease_agreement_documents']

    def to_representation(self, instance):
        # Get the original representation
        representation = super().to_representation(instance)

        # Construct the full URL for the profile picture
        if instance.image:
            representation['image'] = f"http://{settings.IMAGE_HOST}:{settings.IMAGE_PORT}{instance.image.url}"

        if instance.lease_agreement_documents:
            representation['lease_agreement_documents'] = f"http://{settings.IMAGE_HOST}:{settings.IMAGE_PORT}/media/{instance.lease_agreement_documents}"

        return representation

class PaymentDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentDetails
        fields = '__all__'
