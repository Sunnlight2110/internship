# Third-party Imports
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated

# Local Application Imports
from .models import (
    Application,
    SupportingDocument,
    Lease,
    PaymentDetails
)
from .serializers import (
    ApplicationSerializer,
    SpousePartnerDetailSerializer,
    ApplicationListingSerializer,
    SupportingDocumentSerializer,
    LeaseSerializer,
    PaymentDetailsSerializer
)
from Utilities.utils import (
    send_application_status_update_email,
    send_property_manager_email,
    send_payment_confirmation_to_tenant
)

class ApplicationDetailAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, unit_id=None):

        if not unit_id:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Unit ID is required.'}, status=status.HTTP_400_BAD_REQUEST)

        applications = Application.objects.filter(user=request.user).exclude(status="Rejected")
        if unit_id:
            applications = applications.filter(unit_details__id=unit_id)

        if not applications.exists():
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'No applications found for this unit.'},
                            status=status.HTTP_200_OK)

        # Serialize application data
        application_data = []
        for application in applications:
            spouse_details = application.spouse_partner_details.first()
            spouse_serialized = SpousePartnerDetailSerializer(spouse_details).data if spouse_details else None
            app_data = ApplicationSerializer(application).data
            app_data['spouse_partner_details'] = spouse_serialized if spouse_serialized else None
            application_data.append(app_data)

        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'data': application_data}, status=status.HTTP_200_OK)

    def post(self, request):
        data = request.data
        application_id = data['application_id']

        if application_id == 0:
            serializer = ApplicationSerializer(data=data)

            if serializer.is_valid():
                application = serializer.save()
                application.user = request.user
                application.save()

                return Response({'status': status.HTTP_201_CREATED, 'result': "1",
                                 'message': 'Application data added successfully.',
                                 'data': serializer.data}, status=status.HTTP_200_OK)

            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                            'message': serializer.errors}, status=status.HTTP_200_OK)

        else:
            try:
                application = Application.objects.get(id=application_id)
            except Application.DoesNotExist:
                return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                                 'message': 'Application not found.'}, status=status.HTTP_200_OK)

            # Update application data
            application_serializer = ApplicationSerializer(application, data=data, partial=True)
            if application_serializer.is_valid():
                application_serializer.save()
                if application_serializer.data['status'] == "In Review":
                    property_details = application.unit_details.property_details
                    rejection_message = None
                    send_application_status_update_email(application, application_serializer.data['status'], rejection_message, property_details)
                    send_property_manager_email(application, property_details)

                return Response({'status': status.HTTP_200_OK, 'result': "1",
                                 'message': 'Application data updated successfully.',
                                'data': application_serializer.data}, status=status.HTTP_200_OK)

            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                            'message': application_serializer.errors}, status=status.HTTP_200_OK)

class ListAllApplicationDetailAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        # applications_to_update = Application.objects.filter(
        #     user=request.user,
        #     rejection_blocked_until__gt=now(),
        #     lease_agreement_id__isnull=True
        # )
        # applications_to_update.update(lease_agreement_id="1234")
        applications = Application.objects.filter(user=request.user).exclude(status="Agreement Signed").order_by('-id')
        serializer = ApplicationListingSerializer(applications, many=True)
        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'message': 'Application successfully facth.',
                         'data': serializer.data}, status=status.HTTP_200_OK)

class SupportingDocumentAPIView(APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request):
        # user = request.user
        serializer = SupportingDocumentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'Document successfully uploaded.',
                             'data': serializer.data}, status=status.HTTP_200_OK)

        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'message': serializer.errors}, status=status.HTTP_200_OK)

    def delete(self, request):
        file_url = request.data.get('file_url', None)

        if file_url:
            file_name = file_url.split('/')[-1]
            file_path = f'documents/{file_name}'
            try:
                document = SupportingDocument.objects.get(file=file_path)
                document.delete()

                return Response({'status': status.HTTP_200_OK, 'result': "1",
                                 'message': 'Document successfully deleted.'},
                                status=status.HTTP_200_OK)

            except SupportingDocument.DoesNotExist:
                return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                                 'message': 'Document not found.'}, status=status.HTTP_404_NOT_FOUND)
        else:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'file_url not provided.'}, status=status.HTTP_400_BAD_REQUEST)

class ListAllLeaseAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        print(request.user)
        lease = Lease.objects.filter(application_details__user=request.user)
        serializer = LeaseSerializer(lease, many=True)
        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'message': 'Lease successfully facth.',
                         'data': serializer.data}, status=status.HTTP_200_OK)

class PaymentDetailsPIView(APIView):

    def get(self, request, lease_id=None):
        if lease_id:
            try:
                # Try to fetch the payment details using the lease_id
                payment = PaymentDetails.objects.get(lease_details=lease_id)
            except PaymentDetails.DoesNotExist:
                # If payment details are not found, return a 404 not found error
                return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                                 'message': 'Payment details not found'},
                                status=status.HTTP_200_OK)

            # Serialize the list of payment details
            serializer = PaymentDetailsSerializer(payment)
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': "Payment details retrieved successfully.",
                             'data': serializer.data}, status=status.HTTP_200_OK)

        # If lease_id is not provided, return a bad request response
        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'message': "lease id is required"}, status=status.HTTP_200_OK)

    def post(self, request, *args, **kwargs):
        data = request.data

        serializer = PaymentDetailsSerializer(data=data)
        if serializer.is_valid():
            payment_details = serializer.save()
            lease = payment_details.lease_details
            lease.lease_status = 'Completed'
            lease.payment_id = payment_details.payment_id
            lease.payment_date = payment_details.created_at
            lease.save()
            serializer.save()
            send_payment_confirmation_to_tenant(payment_details, lease)
            return Response({'status': status.HTTP_201_CREATED, 'result': "1",
                             'message': 'Payment completed successfully',
                             'data': serializer.data}, status=status.HTTP_200_OK)

        # Return detailed error messages when the serializer is invalid
        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'message': 'Invalid data provided',
                         'errors': serializer.errors}, status=status.HTTP_200_OK)
