# Third-party Imports
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated

# Django Imports
from django.shortcuts import get_object_or_404

# Local Application Imports
from .models import CMS
from .serializers import CMSSerializer

class CMSView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, pk=None):
        if pk:
            cms_instance = get_object_or_404(CMS, pk=pk)
            serializer = CMSSerializer(cms_instance)
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': "CMS record retrieved successfully.",
                             'data': serializer.data}, status=status.HTTP_200_OK)
        else:
            cms_instances = CMS.objects.all()
            serializer = CMSSerializer(cms_instances, many=True)
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': "CMS records retrieved successfully.",
                             'data': serializer.data}, status=status.HTTP_200_OK)

    def post(self, request):
        serializer = CMSSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'status': status.HTTP_201_CREATED, 'result': "1",
                             'message': 'CMS created successfully.',
                             'data': serializer.data}, status=status.HTTP_200_OK)
        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'message': 'Invalid data', 'errors': serializer.errors},
                        status=status.HTTP_200_OK)

    def patch(self, request, pk):
        cms_instance = get_object_or_404(CMS, pk=pk)  # Get the CMS instance or return 404
        serializer = CMSSerializer(cms_instance, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'CMS updated successfully.',
                             'data': serializer.data}, status=status.HTTP_200_OK)
        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'errors': serializer.errors}, status=status.HTTP_200_OK)
