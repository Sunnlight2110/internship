from django.contrib import admin
from .models import PropertyDevelopment

admin.site.register(PropertyDevelopment)
