# Django Imports
from django.conf import settings

# Third-party Imports
from rest_framework import serializers

# Local Application Imports
from quickprops_app.models import User, Company
from .models import (
    PropertyDevelopment,
    PropertyImage,
    Block,
    Unit,
    UnitImage,
    CMS
)

class CompanySerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = ['id', 'user', 'name', 'company_logo']

    def to_representation(self, instance):
        # Get the original representation
        representation = super().to_representation(instance)

        # Construct the full URL for the company logo
        if instance.company_logo:
            representation['company_logo'] = f"http://{settings.IMAGE_HOST}:{settings.IMAGE_PORT}{instance.company_logo.url}"

        return representation

class CompanyListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = ['id', 'name']

class UserCreationSerializer(serializers.ModelSerializer):
    company_name = serializers.CharField(write_only=True, required=False)

    class Meta:
        model = User
        fields = ['id', 'full_name', 'email', 'phone_number', 'user_role', 'profile_picture',
                  'company_name', 'company_id', 'address', 'dob', 'gender', 'is_active']

    def create(self, validated_data):
        company_name = validated_data.pop('company_name', None)

        # Create the User instance
        user = User.objects.create(**validated_data)

        # Check if user_role is 3 and create a Company instance
        if validated_data.get('user_role') and validated_data['user_role'].id == 3:
            # Create Company with name and user
            company = Company.objects.create(name=company_name, user=user)  # Create Company
            user.company_id = company.id  # Save the company ID in user model
            user.save(update_fields=['company_id'])  # Update user with the company ID

        return user

    def update(self, instance, validated_data):
        company_name = validated_data.pop('company_name', None)

        # Update user fields
        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        instance.save()

        # Update company if user_role is 3 and company_name is provided
        if company_name:
            # If the company already exists, update it
            if instance.company_id:
                company = Company.objects.get(id=instance.company_id)
                company.name = company_name
                company.save()
            else:
                # If company does not exist, create a new one
                company = Company.objects.create(name=company_name, user=instance)
                instance.company_id = company.id

        return instance

class GetUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'full_name', 'email', 'phone_number', 'profile_picture', 'company_id',
                  'user_role', 'address', 'dob', 'gender', 'is_active']

class UserSerializer(serializers.ModelSerializer):
    user_role = serializers.SerializerMethodField()
    profile_picture = serializers.ImageField(required=False)
    company_details = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['id', 'full_name', 'email', 'phone_number', 'address', 'dob', 'gender',
                  'profile_picture', 'user_role', 'is_active', 'company_id', 'company_details',
                  'created_at', 'updated_at']

    def validate(self, data):
        phone_number = data.get('phone_number')

        if phone_number:
            # Check if phone number already exists
            if User.objects.filter(phone_number=phone_number).exists():
                raise serializers.ValidationError("This phone number is already in use. Please use a different one.")

            # Check if phone number is numeric
            if not phone_number.isdigit():
                raise serializers.ValidationError("Phone number must contain only digits.")

            # Check length of phone number (10 digits)
            if len(phone_number) < 9 or len(phone_number) > 12:
                raise serializers.ValidationError("Phone number must be between 9 and 12 digits long.")
        return data

    def get_user_role(self, obj):
        return obj.user_role.role_name if obj.user_role else None

    def get_company_details(self, obj):
        company = Company.objects.filter(user=obj).first()
        return CompanySerializer(company).data if company else None

    def to_representation(self, instance):
        # Get the original representation
        representation = super().to_representation(instance)

        # Construct the full URL for the profile picture
        if instance.profile_picture:
            representation['profile_picture'] = f"http://{settings.IMAGE_HOST}:{settings.IMAGE_PORT}{instance.profile_picture.url}"

        return representation

class PropertyImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = PropertyImage
        fields = ['id', 'image']

class AddPropertyDevelopmentSerializer(serializers.ModelSerializer):
    images = PropertyImageSerializer(many=True, read_only=True)
    class Meta:
        model = PropertyDevelopment
        fields = ['id', 'user', 'company', 'property_manager', 'property_name', 'property_type',
                  'address', 'city', 'province', 'security_features', 'nearby_transport',
                  'property_status', 'latitude', 'longitude', 'images', 'created_at', 'updated_at']

class ViewPropertyDevelopmentSerializer(serializers.ModelSerializer):
    images = PropertyImageSerializer(many=True, required=False)
    class Meta:
        model = PropertyDevelopment
        fields = ['id', 'user', 'company', 'property_manager', 'property_name', 'property_type',
                  'address', 'city', 'province', 'security_features', 'nearby_transport',
                  'property_status', 'latitude', 'longitude', 'images', 'created_at', 'updated_at']

class ListPropertyDevelopmentSerializer(serializers.ModelSerializer):
    images = PropertyImageSerializer(many=True, required=False)
    class Meta:
        model = PropertyDevelopment
        fields = ['id', 'user', 'company', 'property_manager', 'property_name', 'property_type',
                  'address', 'city', 'province', 'security_features', 'nearby_transport',
                  'property_status', 'latitude', 'longitude', 'images', 'created_at', 'updated_at']

class BlockSerializer(serializers.ModelSerializer):
    class Meta:
        model = Block
        fields = ['id', 'user', 'property_details', 'block_name', 'number_of_units',
                  'common_area_features', 'block_status']

class UnitImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = UnitImage
        fields = ['id', 'image']

class UnitSerializer(serializers.ModelSerializer):
    images = UnitImageSerializer(many=True, read_only=True)

    class Meta:
        model = Unit
        fields = ['id', 'user', 'property_details', 'block_details', 'unit_type', 'images',
                  'number_of_bedrooms', 'number_of_bathrooms', 'number_of_balconies',
                  'parking_spaces', 'pet_policy', 'is_vacant', 'unit_status', 'furnishing_status',
                  'additional_amenities', 'unit_security_features', 'unit_no', 'rent', 'deposit',
                  'available_from', 'unit_description']

class ShowUnitSerializer(serializers.ModelSerializer):
    images = PropertyImageSerializer(many=True, required=False)

    class Meta:
        model = Unit
        fields = ['id', 'user', 'property_details', 'block_details', 'unit_type', 'images',
                  'number_of_bedrooms', 'number_of_bathrooms', 'number_of_balconies',
                  'parking_spaces', 'pet_policy', 'is_vacant', 'unit_status', 'furnishing_status',
                  'additional_amenities', 'unit_security_features', 'unit_no', 'rent', 'deposit',
                  'available_from', 'unit_description']

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        # Check for additional_amenities and modify if it contains [""]
        if 'additional_amenities' in representation:
            if representation['additional_amenities'] == [""]:
                representation['additional_amenities'] = []

        if 'unit_security_features' in representation:
            if representation['unit_security_features'] == [""]:
                representation['unit_security_features'] = []

        return representation

class CMSSerializer(serializers.ModelSerializer):
    class Meta:
        model = CMS
        fields = ['id', 'title', 'content']
