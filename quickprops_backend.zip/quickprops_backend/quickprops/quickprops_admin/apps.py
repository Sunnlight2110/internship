from django.apps import AppConfig


class QuickpropsAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'quickprops_admin'
