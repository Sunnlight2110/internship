# Third-party Imports
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

# Django Imports
from django.core.exceptions import ObjectDoesNotExist

# Local Application Imports
from quickprops_app.models import Permission, UserRole

class PermissionView(APIView):
    def get(self, request, *args, **kwargs):
        roles = UserRole.objects.all()
        permission_data = {}

        for role in roles:
            permissions = Permission.objects.filter(role=role)
            resource_permissions = {}

            for permission in permissions:
                resource_permissions[permission.resource_name] = {
                    "create": permission.create,
                    "view": permission.view,
                    "edit": permission.edit,
                    "delete": permission.delete
                }

            permission_data[role.role_name] = resource_permissions
        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'message': 'Details retrieved successfully.',
                         'data': permission_data}, status=status.HTTP_200_OK)

    def patch(self, request, *args, **kwargs):
        data = request.data
        updated_permissions = {}
        # Iterate over the roles and permissions from the request data
        for role_name, permissions in data.items():
            try:
                # Get the role object
                role = UserRole.objects.get(role_name=role_name)
                updated_permissions[role_name] = {}
                for resource_name, perms in permissions.items():
                    # Check if permission exists for this role and resource
                    permission = Permission.objects.filter(
                        role=role,
                        resource_name=resource_name
                    ).first()

                    if permission:
                        # Update the existing permission
                        permission.create = perms.get('create', permission.create)
                        permission.view = perms.get('view', permission.view)
                        permission.edit = perms.get('edit', permission.edit)
                        permission.delete = perms.get('delete', permission.delete)
                        permission.save()
                    else:
                        # If permission does not exist, create a new one
                        Permission.objects.create(
                            role=role,
                            resource_name=resource_name,
                            create=perms.get('create', False),
                            view=perms.get('view', False),
                            edit=perms.get('edit', False),
                            delete=perms.get('delete', False)
                        )
                    updated_permissions[role_name][resource_name] = {
                        "create": permission.create,
                        "view": permission.view,
                        "edit": permission.edit,
                        "delete": permission.delete
                    }

            except ObjectDoesNotExist:
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': f"Role {role_name} does not exist."},
                                status=status.HTTP_200_OK)
        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'message': 'Permissions updated successfully.',
                         'data': updated_permissions}, status=status.HTTP_200_OK)
