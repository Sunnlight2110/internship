# Standard library
import os
import json
from datetime import datetime, timedelta, date

# Django Imports
from django.contrib.auth import authenticate
from django.utils import timezone
from django.contrib.auth.hashers import make_password
from django.shortcuts import get_object_or_404
from django.conf import settings
from django.db.models import Q
from django.utils.timezone import now
from django.core.files.base import ContentFile

# Third-party Imports
import requests
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken

# Local Application Imports
from quickprops_app.models import (
    User,
    UserToken,
    Company,
    Application,
    AgreementDocument,
    Lease,
    Permission
)
from quickprops_app.serializers import ApplicationSerializer, LeaseSerializer
from Utilities.utils import (
    generate_otp,
    send_password_reset_otp,
    send_email_resend_otp,
    generate_random_password,
    send_password_via_email,
    send_phone_otp,
    send_application_status_update_email,
    send_cancelled_application_status_email,
    generate_lease_agreement
    )
from .models import (
    PropertyDevelopment,
    PropertyImage,
    Block,
    Unit,
    UnitImage
)
from .serializers import (
    UserSerializer,
    AddPropertyDevelopmentSerializer,
    ViewPropertyDevelopmentSerializer,
    ListPropertyDevelopmentSerializer,
    BlockSerializer,
    UnitSerializer,
    UserCreationSerializer,
    GetUserSerializer,
    CompanyListSerializer,
    CompanySerializer
)

class LoginAPIView(APIView):
    def post(self, request):
        email = request.data.get('email')
        password = request.data.get('password')

        # Check if email and password are provided
        if not email:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Email is required.'}, status=status.HTTP_200_OK)

        if not password:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Password is required.'}, status=status.HTTP_200_OK)

        email = email.lower()
        # Check if the user with this email exists
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': "Email id not found."}, status=status.HTTP_200_OK)

        # Check if the user is active
        if not user.is_active:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Account is inactive.'}, status=status.HTTP_200_OK)

        # Check if the user_role is 1
        if user.user_role.id == 1:
            return Response({'status': status.HTTP_401_UNAUTHORIZED, 'result': "0",
                             'message': 'Tenant users are not allowed to log in.'},
                            status=status.HTTP_200_OK)

        # Authenticate user
        user = authenticate(request, email=email, password=password)

        if user is not None:
            user.last_login = timezone.now()
            user.save()
            # User is authenticated
            # Get the user role
            user_role = user.user_role.role_name if user.user_role else 'No Role Assigned'

            # Generate JWT tokens
            refresh = RefreshToken.for_user(user)
            access_token = str(refresh.access_token)
            refresh_token = str(refresh)

            user_token, created = UserToken.objects.get_or_create(user=user)
            user_token.access_token = access_token
            user_token.refresh_token = refresh_token
            user_token.save()

            return Response({
                'status': status.HTTP_200_OK, 'result': "1",
                'message': "Login successful",
                'tokens': {
                    'access': access_token,
                    'refresh': refresh_token
                },
                'user': {
                    'full_name': user.full_name,
                    'email': user.email,
                    'phone_number': user.phone_number,
                    'user_role': user_role,
                    'profile_picture': user.profile_picture.url if user.profile_picture else None,
                }
            }, status=status.HTTP_200_OK)

        else:
            # Authentication failed
            return Response({'status': status.HTTP_401_UNAUTHORIZED, 'result': "0",
                             'message': 'Invalid password'}, status=status.HTTP_200_OK)

class ForgetPasswordSendMail(APIView):
    def post(self, request):
        try:
            # Get the email from the request data
            email = request.data.get('email')

            # Validate if email is provided
            if not email:
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': 'Email is required.'}, status=status.HTTP_200_OK)
            email = email.lower()
            # Check if the user with the provided email exists
            if User.objects.filter(email=email).exists():
                user = User.objects.get(email=email)

                # Check if the user is active
                if not user.is_active:
                    return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                                    'message': 'Account is inactive.'}, status=status.HTTP_200_OK)

                # Check if the user_role is 1
                if user.user_role.id == 1:
                    return Response({'status': status.HTTP_401_UNAUTHORIZED, 'result': "0",
                                    'message': 'Tenant users are not allowed to Forget Password.'},
                                    status=status.HTTP_200_OK)


                otp_code = generate_otp(4)
                user.otp_code = otp_code
                user.otp_expiry_time = datetime.now()+timedelta(seconds=300)
                user.save()

                otp_sent_email = send_password_reset_otp(user, otp_code)
                otp_sent_phone = send_phone_otp(user.phone_number, otp_code)

                if otp_sent_email or (otp_sent_phone and otp_sent_phone.status_code == 201):
                    return Response(
                        {
                            'status': status.HTTP_200_OK, 'result': "1",
                            'message': 'Please check your email and mobile for the password reset.'
                        },
                        status=status.HTTP_200_OK)
                else:
                    return Response({'status': status.HTTP_500_INTERNAL_SERVER_ERROR, 'result': "0",
                                     'message': 'Failed to send OTP.'}, status=status.HTTP_200_OK)

            else:
                # If user does not exist, return an error response
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': 'Invalid Email'}, status=status.HTTP_200_OK)

        except Exception as e:
            # Handle any exceptions and return an error response
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': str(e)}, status=status.HTTP_200_OK)

class ResendOTPView(APIView):
    def post(self, request):
        email = request.data.get('email')

        # Validate the email field
        if not email:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Email is required.'}, status=status.HTTP_200_OK)

        email = email.lower()
        # Check if a user with the provided email exists
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Email id not found.'}, status=status.HTTP_200_OK)

        # Generate a new OTP code
        user.otp_code = generate_otp(4)
        user.otp_expiry_time = datetime.now()+timedelta(seconds=300)
        user.save()

        # Send the OTP via email and mobile
        otp_sent_email = send_email_resend_otp(user, user.otp_code)
        otp_sent_phone = send_phone_otp(user.phone_number, user.otp_code)

        if otp_sent_email or (otp_sent_phone and otp_sent_phone.status_code == 201):
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'OTP has been resent. Kindly check your email or mobile.'},
                            status=status.HTTP_200_OK)
        else:
            return Response({'status': status.HTTP_500_INTERNAL_SERVER_ERROR, 'result': "0",
                             'message': 'Failed to send OTP.'}, status=status.HTTP_200_OK)

class OTPVerificationView(APIView):

    def post(self, request):
        data = request.data
        email = data.get('email')
        otp = data.get('otp')

        # Check if email and OTP are provided
        if not email:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Email are required.'}, status=status.HTTP_200_OK)
        if not otp:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'OTP are required.'}, status=status.HTTP_200_OK)
        email = email.lower()
        try:
            # Find the user with the provided email
            user = User.objects.get(email=email)
            current_otp_time = timezone.now()
            if current_otp_time < user.otp_expiry_time:

                # Check if the OTP matches
                if user.otp_code == otp:
                    # Mark email as verified
                    user.is_otp_code_verified = True
                    user.otp_code_verified_at = timezone.now()
                    user.save()
                    return Response({'status': status.HTTP_200_OK, 'result': "1",
                                    'message': 'OTP verified successfully.'},
                                    status=status.HTTP_200_OK)
                else:
                    return Response({'status': status.HTTP_403_FORBIDDEN, 'result': "0",
                                     'message': 'Invalid OTP.'}, status=status.HTTP_200_OK)
            else:
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': 'OTP Expired.'}, status=status.HTTP_200_OK)
        except User.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'User not found.'}, status=status.HTTP_200_OK)

class ForgetPassword(APIView):
    def post(self, request):
        data = request.data
        email = data.get('email')
        new_password = data.get('new_password')
        confirm_password = data.get('confirm_password')

        # Validate required fields
        required_fields = {
            'email': 'Email is required.',
            'new_password': 'New password are required.',
            'confirm_password': 'Confirm Password is required.',
        }
        for field, message in required_fields.items():
            if not data.get(field) or data[field].strip() == "":
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': message}, status=status.HTTP_200_OK)

        # Check if new password and confirm password match
        if new_password != confirm_password:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'New password and confirm password do not match.'},
                            status=status.HTTP_200_OK)
        email = email.lower()
        try:
            # Find the user with the provided email
            user = User.objects.get(email=email)
            if user.is_otp_code_verified:
                user.password = make_password(new_password)
                user.save()
                return Response({'status': status.HTTP_200_OK, 'result': "1",
                                 'message': 'Password has been reset successfully.'},
                                status=status.HTTP_200_OK)
            else:
                # If OTP is not verified, return an error message
                return Response({'status': status.HTTP_403_FORBIDDEN, 'result': "0",
                                 'message': 'OTP verification required before resetting password.'},
                                status=status.HTTP_200_OK)
        except User.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'User not found.'}, status=status.HTTP_200_OK)

class AdminLogoutAPI(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user  # Get the logged-in user
        try:
            # Try to get the UserToken associated with the user
            user_token = UserToken.objects.get(user=user)

            # Delete the token
            user_token.delete()

            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': "Logout successful"}, status=status.HTTP_200_OK)

        except UserToken.DoesNotExist:
            # If the token does not exist, that means the user is already logged out
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': "User is already logged out or token not found"},
                            status=status.HTTP_200_OK)

class ChangePassword(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        data = request.data
        user = request.user
        old_password = data.get('old_password')
        new_password = data.get('new_password')
        confirm_password = data.get('confirm_password')

        required_fields = {
            'old_password': 'Current Password is required.',
            'new_password': 'New password is required.',
            'confirm_password': 'Confirm Password is required.',
        }
        for field, message in required_fields.items():
            if not data.get(field) or data[field].strip() == "":
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                'message': message}, status=status.HTTP_200_OK)

        # Authenticate the user with old password
        user = authenticate(email=user.email, password=old_password)
        if user is None:
            return Response({'status': status.HTTP_403_FORBIDDEN, 'result': "0",
                             'message': 'Current password is incorrect.'}, 
                            status=status.HTTP_200_OK)

        # Check if new password is the same as old password
        if old_password == new_password:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'New Password must be different from Current Password.'},
                            status=status.HTTP_200_OK)

        # Check if new password and confirm password match
        if new_password != confirm_password:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'New Password and Confirm Password do not match.'},
                            status=status.HTTP_200_OK)

        # Set the new password
        user.set_password(new_password)
        user.save()

        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'message': 'Password changed successfully.'},
                        status=status.HTTP_200_OK)

class UserProfileAPI(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        try:
            # Fetch user object based on the logged-in user's ID
            user = get_object_or_404(User, id=request.user.id)

            # Serialize the user data
            serializer = UserSerializer(user)
            if user.user_role:
                role = user.user_role

                # Fetch permissions for the user's role
                permissions = Permission.objects.filter(role=role)

                # Format permissions into a dictionary
                permissions_dict = {}
                for perm in permissions:
                    if perm.resource_name not in permissions_dict:
                        permissions_dict[perm.resource_name] = {
                            "create": perm.create,
                            "view": perm.view,
                            "edit": perm.edit,
                            "delete": perm.delete,
                        }
                    else:
                        resource = permissions_dict[perm.resource_name]
                        resource["create"] = perm.create or resource["create"]
                        resource["view"] = perm.view or resource["view"]
                        resource["edit"] = perm.edit or resource["edit"]
                        resource["delete"] = perm.delete or resource["delete"]

                # Add permissions to the serialized user data
                user_data = serializer.data
                user_data['permissions'] = {role.role_name: permissions_dict}
            else:
                user_data = serializer.data
                user_data['permissions'] = {}

            # Return the user data in the response
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'data': user_data}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': str(e)}, status=status.HTTP_200_OK)
    def patch(self, request, *args, **kwargs):
        try:
            data = request.data

            # Fetch the user object
            user = get_object_or_404(User, id=request.user.id)

            # Partial update user data
            serializer = UserSerializer(user, data=data, partial=True)

            if serializer.is_valid():
                new_profile_picture = request.FILES.get('profile_picture')
                if new_profile_picture and user.profile_picture:
                    # Delete the old profile picture
                    old_picture_path = user.profile_picture.path
                    if os.path.exists(old_picture_path):
                        os.remove(old_picture_path)
                serializer.save()
                return Response({'status': status.HTTP_200_OK, 'result': "1",
                                 'message': 'Profile updated successfully',
                                 'data': serializer.data}, status=status.HTTP_200_OK)
            error_messages = serializer.errors.get('non_field_errors', [])

            if error_messages:
                # Join the error messages into a single string
                error_message = " ".join(error_messages)
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': error_message}, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': str(e)}, status=status.HTTP_200_OK)

class CreateUserAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, user_id=None):
        if user_id is not None:
            try:
                user = User.objects.get(id=user_id)
                user_serializer = GetUserSerializer(user)
                return Response({'status': status.HTTP_200_OK, 'result': "1",
                                 'message': 'Details retrieved successfully.',
                                 'data': user_serializer.data}, status=status.HTTP_200_OK)

            except User.DoesNotExist:
                return Response({"status": status.HTTP_400_BAD_REQUEST, "result": "0",
                                 "message": "User not found."}, status=status.HTTP_200_OK)

    def post(self, request):
        data = request.data.copy()

        if 'email' in data:
            data['email'] = data['email'].lower()

        # Validate required fields
        required_fields = {
            'full_name': 'Name is required.',
            'email': 'Email is required.',
            'phone_number': 'Phone Number is required.',
        }
        for field, message in required_fields.items():
            if not data.get(field) or data[field].strip() == "":
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': message}, status=status.HTTP_200_OK)

        # Check if a user with the same email already exists
        if User.objects.filter(email=data.get('email').lower()).exists():
            return Response(
                {
                    'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                    'message': 'User with this email already exists. Please try a new one.'
                },
                status=status.HTTP_200_OK)

        # Check if a user with the same phone number already exists
        if User.objects.filter(phone_number=data.get('phone_number')).exists():
            return Response(
                {
                    'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                    'message': 'User with this phone number already exists. Please try a new one.'
                },
                status=status.HTTP_200_OK
            )

        random_password = generate_random_password()

        data['password'] = random_password

        serializer = UserCreationSerializer(data=data)

        if serializer.is_valid():
            user = serializer.save()
            user.is_active = True
            user.set_password(random_password)
            if data.get('user_role') == 1:
                user.is_otp_code_verified = True
            user.save()
            sent_email = send_password_via_email(user, random_password)
            if sent_email:
                return Response({'status': status.HTTP_201_CREATED, 'result': "1",
                                 'message': 'User created successfully.',
                                 'data': serializer.data}, status=status.HTTP_200_OK)

        error_messages = serializer.errors.get('non_field_errors', [])
        if error_messages:
            # Join the error messages into a single string
            error_message = " ".join(error_messages)
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': error_message, }, status=status.HTTP_200_OK)

        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'message': 'Invalid data', 'errors': serializer.errors},
                        status=status.HTTP_200_OK)

    def patch(self, request, user_id):
        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response(
                {'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                 'message': 'User not found.'}, status=status.HTTP_200_OK)

        data = request.data.copy()

        if 'email' in data:
            data['email'] = data['email'].lower()

        # Check if 'is_active' is being updated
        if 'is_active' in data:
            # Check if the user is assigned to any PropertyDevelopment
            is_assigned = PropertyDevelopment.objects.filter(
                Q(property_manager=user) | Q(company__user=user)
                ).exists()
            if is_assigned:
                return Response(
                    {
                        'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                        'message': 'User is assigned to a property. You cannot change status.'
                    },
                    status=status.HTTP_200_OK
                )

        # Check if a user with the same email already exists (except for the current user)
        if 'email' in request.data and User.objects.filter(
            email=request.data['email'].lower()).exclude(id=user_id).exists():
            return Response(
                {
                    'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                    'message': 'User with this email already exists. Please try a new one.'
                },
                status=status.HTTP_200_OK
            )

        # Check if a user with the same phone number already exists (except for the current user)
        if 'phone_number' in data and User.objects.filter(
            phone_number=data['phone_number']).exclude(id=user_id).exists():
            return Response(
                {
                    'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                    'message': 'This phone number is already in use. Please use a different one.'
                },
                status=status.HTTP_200_OK
            )

        # Create a serializer instance with the existing user data
        serializer = UserCreationSerializer(user, data=data, partial=True)
        if serializer.is_valid():
            user = serializer.save()
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'User Updated successfully.',
                             'data': serializer.data}, status=status.HTTP_200_OK)

        error_messages = serializer.errors.get('non_field_errors', [])
        if error_messages:
            # Join the error messages into a single string
            error_message = " ".join(error_messages)
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': error_message}, status=status.HTTP_200_OK)

        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'message': 'Invalid data', 'errors': serializer.errors},
                        status=status.HTTP_200_OK)

    def delete(self, request, user_id):
        try:
            user = User.objects.get(id=user_id)
            if user.user_role.id == 3:
                if PropertyDevelopment.objects.filter(company__id=user.company_id).exists():
                    return Response(
                        {
                            'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                            'message': 'Cannot delete user because associated company is linked to a property development.'
                        },
                        status=status.HTTP_200_OK
                    )
            elif user.user_role.id == 4:
                if PropertyDevelopment.objects.filter(property_manager=user.id).exists():
                    return Response(
                        {
                            'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                            'message': 'Cannot delete user because associated company is linked to a property development.'
                        },
                        status=status.HTTP_200_OK
                    )

            user.delete()
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'User deleted successfully.'}, status=status.HTTP_200_OK)
        except User.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'User not found.'}, status=status.HTTP_200_OK)

class GetAllUserAPIView(APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request):
        # Fetch data from POST request body (request.data)
        page = request.data.get('page', 1)
        page_size = request.data.get('page_size', 10)
        search = request.data.get('search', '')
        is_active = request.data.get('is_active', None)
        user_role = request.data.get('user_role', None)

        # Validate page and page_size to ensure they are integers
        try:
            page = int(page)
            page_size = int(page_size)
        except ValueError:
            return Response({"status": status.HTTP_400_BAD_REQUEST, "result": "0",
                             "message": "Invalid page or page_size. Must be integers."},
                            status=status.HTTP_200_OK)

        # Filter users based on role
        role = request.user.user_role.id
        if role == 3:
            company = request.user.company_id
            users = User.objects.filter(company_id=company).exclude(
                id=request.user.id).order_by('-created_at')
        else:
            users = User.objects.all().exclude(user_role=2).order_by('-created_at')

        search_filter = Q()
        if search:
            # search_filter = Q()
            search_fields = ['full_name', 'email', 'phone_number']

            for field in search_fields:
                search_filter |= Q(**{f"{field}__icontains": search})

            users = users.filter(search_filter)

        if is_active is not None:
            # Ensure `is_active` is either True or False
            if is_active.lower() == 'active':
                users = users.filter(is_active=True)
            elif is_active.lower() == 'inactive':
                users = users.filter(is_active=False)
            else:
                users = users.all()

        # Apply user_role filter if provided
        if user_role:
            users = users.filter(user_role=user_role)

        start = (page - 1) * page_size
        end = start + page_size
        paginated_users = users[start:end]

        user_serializer = GetUserSerializer(paginated_users, many=True)
        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'message': 'Details retrieved successfully.',
                         'data': user_serializer.data,
                         'pagination': {'page': page,
                                        'page_size': page_size,
                                        'total_records': users.count(),
                                        'total_pages': (users.count() + page_size - 1)
                                        }}, status=status.HTTP_200_OK)


class GetCompanyDetailsAPIView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        companies = Company.objects.filter(user__is_active=True).order_by('name')
        company_serializer = CompanyListSerializer(companies, many=True)
        return Response({'status': status.HTTP_200_OK, 'result': "1",
                        'data': company_serializer.data}, status=status.HTTP_200_OK)

class CompanyUpdateAPIView(APIView):
    permission_classes = [IsAuthenticated]
    def patch(self, request, pk):
        # Fetch the company instance
        company = get_object_or_404(Company, pk=pk)

        # Partially update the company instance with the request data
        serializer = CompanySerializer(company, data=request.data, partial=True)

        # Validate and save the updated data
        if serializer.is_valid():
            serializer.save()
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'Company Logo updated successfully',
                             'data': serializer.data}, status=status.HTTP_200_OK)
        else:
            error_messages = serializer.errors.get('non_field_errors', [])
            if error_messages:
                error_message = " ".join(error_messages)
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': error_message}, status=status.HTTP_200_OK)

class ListPropertyManagerAPIView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        role = request.user.user_role.id
        if role == 3:
            company = request.user.company_id
            property_managers = User.objects.filter(is_active=True, user_role=4, company_id=company)
        else:
            property_managers = User.objects.filter(is_active=True, user_role=4)
        property_managers_serializer = GetUserSerializer(property_managers, many=True)
        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'data': property_managers_serializer.data},
                        status=status.HTTP_200_OK)

class PropertyDevelopmentAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, pk=None):
        if pk:
            # Retrieve a specific property by ID
            try:
                property_development = PropertyDevelopment.objects.get(pk=pk)
                serializer = ViewPropertyDevelopmentSerializer(property_development)
                response_data = serializer.data

                if 'security_features' in response_data:
                    security_features = response_data['security_features']
                    if isinstance(security_features, list):
                        if all(feature == "" for feature in security_features):
                            response_data['security_features'] = [""]
                        else:
                            if security_features[0] == "":
                                security_features = security_features[1:]
                            security_features = [
                                feature for feature in security_features if feature.strip()
                                ]
                            response_data['security_features'] = security_features

                if 'nearby_transport' in response_data:
                    nearby_transport = response_data['nearby_transport']
                    if isinstance(nearby_transport, list):
                        if all(feature == "" for feature in nearby_transport):
                            response_data['nearby_transport'] = [""]
                        else:
                            if nearby_transport[0] == "":
                                nearby_transport = nearby_transport[1:]
                            nearby_transport = [
                                feature for feature in nearby_transport if feature.strip()
                                ]
                            response_data['nearby_transport'] = nearby_transport

                return Response({'status': status.HTTP_200_OK, 'result': "1",
                                 'data': response_data}, status=status.HTTP_200_OK)
            except PropertyDevelopment.DoesNotExist:
                return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                                 'message': 'Property not found.'}, status=status.HTTP_200_OK)
        else:
            role = request.user.user_role.id
            if role == 3:
                company = request.user.company_id
                property_developments = PropertyDevelopment.objects.filter(
                    company=company).exclude(is_deleted=True).order_by('-created_at')
            elif role == 4:
                property_developments = PropertyDevelopment.objects.filter(
                    property_manager=request.user.id
                    ).exclude(is_deleted=True).order_by('-created_at')
            else:
                property_developments = PropertyDevelopment.objects.all().exclude(
                    is_deleted=True).order_by('-created_at')
            serializer = ListPropertyDevelopmentSerializer(property_developments, many=True)
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'data': serializer.data}, status=status.HTTP_200_OK)

    def post(self, request):
        data = request.data

        if not data.get('security_features') or not data['security_features'][0].strip():
            data['security_features'] = json.dumps([""])

        if not data.get('nearby_transport') or not data['nearby_transport'][0].strip():
            data['nearby_transport'] = json.dumps([""])

        # Validate required fields
        required_fields = {
            'property_name': 'Property Name is required.',
            'address': 'Address is required.',
            'city': 'City is required.',
            'province': 'Province is required.',
             }

        for field, message in required_fields.items():
            if not data.get(field) or data[field].strip() == "":
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': message}, status=status.HTTP_200_OK)

        if data['company'] and data['property_name']:
            # Check for an existing property with the same name in the same company
            if PropertyDevelopment.objects.filter(
                company_id=data['company'],
                property_name__iexact=data['property_name'],
                is_deleted=False).exists():
                return Response(
                    {
                        'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                        'message': f"A property with the name '{data['property_name']}' already exists in your company."
                    },
                    status=status.HTTP_200_OK
                )

        serializer = AddPropertyDevelopmentSerializer(data=data)
        # Check if serializer is valid and save
        if serializer.is_valid():
            property_development = serializer.save()
            property_development.user = request.user
            property_development.property_status = True
            property_development.property_type = 'Residential'
            property_development.save()

            images_data = request.FILES.getlist('images')  # Expecting images in a multipart form
            for image_data in images_data:
                PropertyImage.objects.create(property=property_development, image=image_data)

            return Response({'status': status.HTTP_201_CREATED, 'result': "1",
                             'message': 'Property created successfully.',
                             'data': serializer.data}, status=status.HTTP_200_OK)

        # Return serializer errors if invalid
        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'message': serializer.errors}, status=status.HTTP_200_OK)

    def patch(self, request, pk):
        try:
            # Get the property to update
            property_development = PropertyDevelopment.objects.get(pk=pk)
        except PropertyDevelopment.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Property not found.'}, status=status.HTTP_200_OK)
        data = request.data

        # Check if property status is being updated
        if 'property_status' in request.data:
            property_status = request.data['property_status'].lower() == 'true'
            new_status = property_status

            # Check if the property is assigned to any Block
            if property_development.blocks.exists():
                property_development.blocks.update(block_status=new_status)

            # Check if the property is assigned to any Unit
            if property_development.units.exists():
                property_development.units.update(unit_status=new_status)

        # Check if property_name or company is being updated and validate conflicts
        if 'property_name' in data or 'company' in data:
            company_id = property_development.company.id
            property_name = data.get('property_name', property_development.property_name)
            company = data.get('company', company_id)

            # Check if a property with the same name exists in the same company
            if PropertyDevelopment.objects.filter(
                company_id=company,
                property_name__iexact=property_name,
                is_deleted=False
            ).exists():
                return Response(
                    {
                        'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                        'message': f"A property with the name '{property_name}' already exists in your company."
                    },
                    status=status.HTTP_200_OK
                )

        # Create a serializer instance with the existing property data
        serializer = AddPropertyDevelopmentSerializer(property_development, data=data, partial=True)

        # Validate and save the updated data
        if serializer.is_valid():
            property_development = serializer.save()
            if 'images' in request.FILES:
                images = request.FILES.getlist('images')
                for image in images:
                    PropertyImage.objects.create(property=property_development, image=image)
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'Property updated successfully.',
                             'data': serializer.data}, status=status.HTTP_200_OK)

        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'message': serializer.errors}, status=status.HTTP_200_OK)

    def delete(self, request, pk):
        try:
            # Get the property to delete
            property_development = PropertyDevelopment.objects.get(pk=pk)

            # Check if the property has any related blocks
            if property_development.blocks.exists():
                return Response(
                    {
                        'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                        'message': 'Cannot delete property because it has associated blocks.'
                    },
                    status=status.HTTP_200_OK
                )

            # Check if the property has any related units
            if property_development.units.exists():
                return Response(
                    {
                        'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                        'message': 'Cannot delete property because it has associated units.'
                    },
                    status=status.HTTP_200_OK
                )

            # Retrieve related images
            related_images = PropertyImage.objects.filter(property=property_development)

            # Delete each image file from the file system
            for property_image in related_images:
                if property_image.image:
                    image_path = os.path.join(settings.MEDIA_ROOT, str(property_image.image))
                    if os.path.exists(image_path):
                        os.remove(image_path)

            # Now delete the images from the database
            related_images.delete()
            property_development.is_deleted = True
            property_development.save()
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'Property deleted successfully.'},
                             status=status.HTTP_200_OK)
        except PropertyDevelopment.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Property not found.'}, status=status.HTTP_200_OK)

class PropertyImageDeleteAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def delete(self, request, pk, image_id):
        try:
            # Get the property and make sure it belongs to the user
            property_development = PropertyDevelopment.objects.get(pk=pk)
        except PropertyDevelopment.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Property not found.'}, status=status.HTTP_200_OK)
        try:
            # Get the specific image linked to the property
            property_image = PropertyImage.objects.get(pk=image_id, property=property_development)
            if property_image.image:
                # Construct the full file path
                image_path = os.path.join(settings.MEDIA_ROOT, str(property_image.image))
                if os.path.exists(image_path):
                    os.remove(image_path)

            property_image.delete()
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'Property Image deleted successfully.'},
                            status=status.HTTP_200_OK)
        except PropertyImage.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Image not found.'}, status=status.HTTP_200_OK)

class GetAllPropertyAPIView(APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request):
        # Fetch data from POST request body (request.data)
        page = request.data.get('page', 1)
        page_size = request.data.get('page_size', 10)
        search = request.data.get('search', '')
        property_status = request.data.get('property_status', None)

        # Validate page and page_size to ensure they are integers
        try:
            page = int(page)
            page_size = int(page_size)
        except ValueError:
            return Response(
                {
                    "status": status.HTTP_400_BAD_REQUEST, "result": "0",
                    "message": "Invalid page or page_size. Must be integers."
                },
                status=status.HTTP_200_OK
            )

        # Filter users based on role
        role = request.user.user_role.id
        if role == 3:
            company = request.user.company_id
            property_developments = PropertyDevelopment.objects.filter(
                company=company).exclude(is_deleted=True).order_by('-created_at')
        elif role == 4:
            property_developments = PropertyDevelopment.objects.filter(
                property_manager=request.user.id).exclude(is_deleted=True
                                                          ).order_by('-created_at')
        else:
            property_developments = PropertyDevelopment.objects.all().exclude(
                is_deleted=True).order_by('-created_at')

        # Apply search filter
        if search:
            search_filter = Q()
            search_fields = ['property_name', 'property_type', 'address', 'city', 'province']
            for field in search_fields:
                search_filter |= Q(**{f"{field}__icontains": search})
            property_developments = property_developments.filter(search_filter)

        # Filter by property_status ("Active" or "Inactive")
        if property_status is not None:
            if property_status.lower() == 'active':
                property_developments = property_developments.filter(property_status=True)
            elif property_status.lower() == 'inactive':
                property_developments = property_developments.filter(property_status=False)
            else:
                property_developments = property_developments.all()

        # Apply pagination
        start = (page - 1) * page_size
        end = start + page_size
        paginated_properties = property_developments[start:end]

        serializer = ListPropertyDevelopmentSerializer(paginated_properties, many=True)
        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'message': 'Details retrieved successfully.',
                         'data': serializer.data,
                         'pagination': {
                            'page': page,
                            'page_size': page_size,
                            'total_records': property_developments.count(),
                            'total_pages': (property_developments.count() + page_size - 1)
                            }}, status=status.HTTP_200_OK)

class DashboardAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        role = request.user.user_role.id
        current_date = date.today()
        future_date = current_date + timedelta(days=30)

        if role == 3:
            company = request.user.company_id
            total_tenant = 0
            total_company_admin = 0
            total_company_manager = User.objects.filter(
                company_id=company, is_active=True, user_role=4).count()
            total_properties = PropertyDevelopment.objects.filter(
                company=company, property_status=True).exclude(is_deleted=True).count()

            property_developments = PropertyDevelopment.objects.filter(company=company)
            total_blocks = Block.objects.filter(
                property_details__in=property_developments).exclude(is_deleted=True).count()
            total_units = Unit.objects.filter(
                property_details__in=property_developments).exclude(is_deleted=True).count()
            total_units_occupied = Unit.objects.filter(
                property_details__in=property_developments, is_vacant=False).exclude(is_deleted=True).count()
            total_units_vacant = Unit.objects.filter(
                property_details__in=property_developments, is_vacant=True).exclude(is_deleted=True).count()

            units = Unit.objects.filter(
                property_details__in=property_developments).exclude(is_deleted=True)
            total_moving_in = Lease.objects.filter(
                unit_details__in=units,
                rental_start_date__gte=current_date,
                rental_start_date__lte=future_date).count()
            total_moving_out = Lease.objects.filter(
                unit_details__in=units,
                rental_termination_date__gte=current_date,
                rental_termination_date__lte=future_date).count()

        elif role == 4:
            total_tenant = 0
            total_company_admin = 0
            total_company_manager = 0
            total_properties = PropertyDevelopment.objects.filter(
                property_manager=request.user.id, property_status=True).exclude(is_deleted=True).count()

            property_developments = PropertyDevelopment.objects.filter(
                property_manager=request.user.id)
            total_blocks = Block.objects.filter(
                property_details__in=property_developments).exclude(is_deleted=True).count()
            total_units = Unit.objects.filter(
                property_details__in=property_developments).exclude(is_deleted=True).count()
            total_units_occupied = Unit.objects.filter(
                property_details__in=property_developments, is_vacant=False).exclude(is_deleted=True).count()
            total_units_vacant = Unit.objects.filter(
                property_details__in=property_developments, is_vacant=True).exclude(is_deleted=True).count()

            units = Unit.objects.filter(property_details__in=property_developments)
            total_moving_in = Lease.objects.filter(
                unit_details__in=units,
                rental_start_date__gte=current_date,
                rental_start_date__lte=future_date).count()
            total_moving_out = Lease.objects.filter(
                unit_details__in=units,
                rental_termination_date__gte=current_date,
                rental_termination_date__lte=future_date).count()

        else:
            total_tenant = User.objects.filter(
                is_superuser=False, is_active=True, user_role=1).count()
            total_company_admin = User.objects.filter(
                is_superuser=False, is_active=True, user_role=3).count()
            total_company_manager = User.objects.filter(
                is_superuser=False, is_active=True, user_role=4).count()
            total_properties = PropertyDevelopment.objects.filter(
                property_status=True).exclude(is_deleted=True).count()
            total_blocks = Block.objects.all().exclude(is_deleted=True).count()
            total_units = Unit.objects.all().exclude(is_deleted=True).count()
            total_units_occupied = Unit.objects.filter(
                is_vacant=False).exclude(is_deleted=True).count()
            total_units_vacant = Unit.objects.filter(
                is_vacant=True).exclude(is_deleted=True).count()
            total_moving_in = Lease.objects.filter(
                rental_start_date__gte=current_date, rental_start_date__lte=future_date).count()
            total_moving_out = Lease.objects.filter(
                rental_termination_date__gte=current_date, rental_termination_date__lte=future_date).count()

        response_data = {
            'status': status.HTTP_200_OK,
            'result': "1",
            'data': {
                'total_tenant': total_tenant,
                'total_company_admin': total_company_admin,
                'total_company_manager': total_company_manager,
                'total_properties': total_properties,
                'total_blocks': total_blocks,
                'total_units': total_units,
                'total_units_occupied': total_units_occupied,
                'total_units_vacant': total_units_vacant,
                'total_moving_in': total_moving_in,
                'total_moving_out': total_moving_out
            }
        }
        return Response(response_data, status=status.HTTP_200_OK)

class BlockAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, pk=None):
        if pk:
            try:
                block = Block.objects.get(pk=pk)
                serializer = BlockSerializer(block)
                response_data = serializer.data

                if 'common_area_features' in response_data:
                    common_area_features = response_data['common_area_features']
                    if isinstance(common_area_features, list):
                        if all(feature == "" for feature in common_area_features):
                            response_data['common_area_features'] = [""]
                        else:
                            if common_area_features[0] == "":
                                common_area_features = common_area_features[1:]
                            common_area_features = [
                                feature for feature in common_area_features if feature.strip()
                                ]
                            response_data['common_area_features'] = common_area_features

                return Response({'status': status.HTTP_200_OK, 'result': "1",
                                 'message': 'Details retrieved successfully.',
                                 'data': response_data}, status=status.HTTP_200_OK)

            except Block.DoesNotExist:
                return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                                 'message': 'Not found.'}, status=status.HTTP_200_OK)
        else:
            role = request.user.user_role.id
            if role == 3:
                company_id = request.user.company_id
                property_developments = PropertyDevelopment.objects.filter(company=company_id)
                blocks = Block.objects.filter(
                    property_details__in=property_developments
                    ).exclude(is_deleted=True).order_by('-created_at')
            elif role == 4:
                property_developments = PropertyDevelopment.objects.filter(
                    property_manager=request.user.id)
                blocks = Block.objects.filter(
                    property_details__in=property_developments
                    ).exclude(is_deleted=True).order_by('-created_at')
            else:
                blocks = Block.objects.all().exclude(is_deleted=True).order_by('-created_at')

            serializer = BlockSerializer(blocks, many=True)
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'Details retrieved successfully.',
                             'data': serializer.data}, status=status.HTTP_200_OK)

    def post(self, request):
        data = request.data

        if not data.get('common_area_features') or not data['common_area_features'][0].strip():
            data['common_area_features'] = [""]

        data['user'] = request.user.id

        required_fields = {
            'block_name': 'Block Name is required.'
        }

        for field, message in required_fields.items():
            if not data.get(field) or data[field].strip() == "":
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': message}, status=status.HTTP_200_OK)

        if Block.objects.filter(
            property_details_id=data['property_details'], block_name__iexact=data['block_name']
            ).exists():
            return Response(
                {
                    'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                    'message': f"A block with the name '{data['block_name']}' already exists for this property."
                },
                status=status.HTTP_200_OK
            )

        serializer = BlockSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response({'status': status.HTTP_201_CREATED, 'result': "1",
                             'message': 'Block created successfully.',
                             'data': serializer.data}, status=status.HTTP_200_OK)

        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'message': 'Invalid data', 'errors': serializer.errors},
                        status=status.HTTP_200_OK)

    def patch(self, request, pk):
        try:
            block = Block.objects.get(pk=pk)
        except Block.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Not found.'}, status=status.HTTP_200_OK)

        # Get current unit count in the block
        current_units_count = block.units.count()

        new_number_of_units = request.data.get('number_of_units')
        if new_number_of_units:
            try:
                new_number_of_units = int(new_number_of_units)
            except ValueError:
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                'message': 'Invalid number of units.'}, status=status.HTTP_200_OK)

            # Check if the new number is less than the current number of units
            if new_number_of_units < current_units_count:
                return Response(
                    {
                        'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                        'message': f'The number of units cannot be less than the existing units {current_units_count}.'
                    },
                    status=status.HTTP_200_OK
                )

        # Get new values
        new_block_name = request.data.get('block_name', block.block_name)
        new_property_details = request.data.get('property_details', block.property_details.id)

        # Check for duplicate block name in the same property (either for the same or new property)
        if Block.objects.filter(
            block_name__iexact=new_block_name,
            is_deleted=False
        ).exclude(pk=block.pk).filter(
            property_details_id__in=[block.property_details.id, new_property_details]
        ).exists():
            return Response(
                {
                    'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                    'message': f"A block with the name '{new_block_name}' already exists for this property."
                },
                status=status.HTTP_200_OK
            )

        serializer = BlockSerializer(block, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'Block details updated successfully.',
                             'data': serializer.data}, status=status.HTTP_200_OK)

        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'message': 'Invalid data', 'errors': serializer.errors},
                        status=status.HTTP_200_OK)

    def delete(self, request, pk):
        try:
            block = Block.objects.get(pk=pk)
            if block.units.exists():
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                'message': 'Cannot delete block because it has associated units.'},
                                status=status.HTTP_200_OK)
            block.is_deleted = True
            block.save()
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'Block deleted successfully.'},
                            status=status.HTTP_200_OK)

        except Block.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Not found.'}, status=status.HTTP_200_OK)

class GetAllBlockAPIView(APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request):
        # Fetch data from POST request body (request.data)
        page = request.data.get('page', 1)
        page_size = request.data.get('page_size', 10)
        search = request.data.get('search', '')

        # Validate page and page_size to ensure they are integers
        try:
            page = int(page)
            page_size = int(page_size)
        except ValueError:
            return Response({"status": status.HTTP_400_BAD_REQUEST, "result": "0",
                             "message": "Invalid page or page_size. Must be integers."},
                            status=status.HTTP_200_OK)

        # Filter users based on role
        role = request.user.user_role.id
        if role == 3:
            company_id = request.user.company_id
            property_developments = PropertyDevelopment.objects.filter(company=company_id)
            blocks = Block.objects.filter(
                property_details__in=property_developments
                ).exclude(is_deleted=True).order_by('-created_at')
        elif role == 4:
            property_developments = PropertyDevelopment.objects.filter(
                property_manager=request.user.id)
            blocks = Block.objects.filter(
                property_details__in=property_developments
                ).exclude(is_deleted=True).order_by('-created_at')
        else:
            blocks = Block.objects.all().exclude(is_deleted=True).order_by('-created_at')

        # Apply search filter
        if search:
            search_filter = Q()
            search_fields = ['block_name', 'number_of_units']
            for field in search_fields:
                search_filter |= Q(**{f"{field}__icontains": search})
            blocks = blocks.filter(search_filter)

        # Apply pagination
        start = (page - 1) * page_size
        end = start + page_size
        paginated_blocks = blocks[start:end]

        serializer = BlockSerializer(paginated_blocks, many=True)
        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'message': 'Details retrieved successfully.',
                         'data': serializer.data,
                         'pagination': {'page': page,
                                        'page_size': page_size,
                                        'total_records': blocks.count(),
                                        'total_pages': (blocks.count() + page_size - 1) // page_size
                                        }}, status=status.HTTP_200_OK)

class BlocksByPropertyAPIView(APIView):
    def get(self, request, property_id):
        try:
            # Get the property by its ID
            property_development = PropertyDevelopment.objects.get(id=property_id)

            # Retrieve all blocks associated with this property
            blocks = Block.objects.filter(property_details=property_development)

            # Serialize the blocks
            serializer = BlockSerializer(blocks, many=True)

            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'data': serializer.data}, status=status.HTTP_200_OK)

        except PropertyDevelopment.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Property not found.'}, status=status.HTTP_404_NOT_FOUND)

class UnitAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, pk=None):
        if pk:
            # Retrieve a specific unit by ID
            try:
                unit = Unit.objects.get(pk=pk)
                serializer = UnitSerializer(unit)
                response_data = serializer.data

                if 'additional_amenities' in response_data:
                    additional_amenities = response_data['additional_amenities']
                    if isinstance(additional_amenities, list):
                        if all(feature == "" for feature in additional_amenities):
                            response_data['additional_amenities'] = [""]
                        else:
                            if additional_amenities[0] == "":
                                additional_amenities = additional_amenities[1:]
                            additional_amenities = [
                                feature for feature in additional_amenities if feature.strip()
                                ]
                            response_data['additional_amenities'] = additional_amenities

                if 'unit_security_features' in response_data:
                    unit_security_features = response_data['unit_security_features']
                    if isinstance(unit_security_features, list):
                        if all(feature == "" for feature in unit_security_features):
                            response_data['unit_security_features'] = [""]
                        else:
                            if unit_security_features[0] == "":
                                unit_security_features = unit_security_features[1:]
                            unit_security_features = [
                                feature for feature in unit_security_features if feature.strip()
                                ]
                            response_data['unit_security_features'] = unit_security_features

                return Response({'status': status.HTTP_200_OK, 'result': "1",
                                 'data': response_data}, status=status.HTTP_200_OK)
            except Unit.DoesNotExist:
                return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                                 'message': 'Not found.'}, status=status.HTTP_200_OK)
        else:
            role = request.user.user_role.id
            if role == 3:
                company_id = request.user.company_id
                property_developments = PropertyDevelopment.objects.filter(company=company_id)
                units = Unit.objects.filter(
                    property_details__in=property_developments
                    ).exclude(is_deleted=True).order_by('-created_at')
            elif role == 4:
                property_developments = PropertyDevelopment.objects.filter(
                    property_manager=request.user.id)
                units = Unit.objects.filter(
                    property_details__in=property_developments
                    ).exclude(is_deleted=True).order_by('-created_at')
            else:
                units = Unit.objects.all().exclude(is_deleted=True).order_by('-created_at')

            serializer = UnitSerializer(units, many=True)
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'Details retrieved successfully.',
                             'data': serializer.data}, status=status.HTTP_200_OK)

    def post(self, request):
        data = request.data
        if not data.get('additional_amenities') or not data['additional_amenities'][0].strip():
            data['additional_amenities'] = json.dumps([""])

        if not data.get('unit_security_features') or not data['unit_security_features'][0].strip():
            data['unit_security_features'] = json.dumps([""])

        block_id = data.get('block_details')

        required_fields = {
            'unit_type': 'Unit Type is required.',
            'pet_policy': 'Pet Policy is required.',
            'furnishing_status': 'Furnishing Status is required.',
        }
        for field, message in required_fields.items():
            if not data.get(field) or data[field].strip() == "":
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                 'message': message}, status=status.HTTP_200_OK)
        if block_id:
            try:
                block = Block.objects.get(id=block_id)
            except Block.DoesNotExist:
                return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                                'message': 'Block not found.'}, status=status.HTTP_200_OK)

            # Check if the block has reached its unit limit
            current_units = block.units.count()
            if current_units >= block.number_of_units:
                return Response(
                    {
                        'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                        'message': f"Cannot add more units. The limit of {block.number_of_units} units has been reached."
                    },
                    status=status.HTTP_200_OK
                )

        if Unit.objects.filter(
            property_details_id=data['property_details'],
            unit_type=data['unit_type'],
            unit_no=data['unit_no'],
            is_vacant=True
            ).exists():
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                            'message': "The same unit number can't be used within the same block."},
                            status=status.HTTP_200_OK)

        serializer = UnitSerializer(data=data)
        if serializer.is_valid():
            unit = serializer.save()
            unit.user = request.user
            unit.is_vacant = True
            unit.unit_status = True
            unit.save()

            # Process images if provided
            images_data = request.FILES.getlist('images')
            for image_data in images_data:
                UnitImage.objects.create(unit=unit, image=image_data)

            return Response({'status': status.HTTP_201_CREATED, 'result': "1",
                             'message': 'Unit created successfully.',
                             'data': serializer.data}, status=status.HTTP_200_OK)

        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'message': 'Invalid data', 'errors': serializer.errors},
                        status=status.HTTP_200_OK)

    def patch(self, request, pk):
        try:
            # Get the property to unit
            unit = Unit.objects.get(pk=pk)
        except Unit.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Unit not found.'}, status=status.HTTP_200_OK)

        data = request.data
        if 'unit_no' in data or 'unit_type' in data or 'property_details' in data:
            unit_no = data.get('unit_no', unit.unit_no)
            unit_type = data.get('unit_type', unit.unit_type)
            property_details = data.get('property_details', unit.property_details_id)

            if Unit.objects.filter(
                property_details_id=property_details,
                unit_type=unit_type,
                unit_no=unit_no,
                is_vacant=True
                ).exclude(pk=pk).exists():
                return Response(
                    {
                        'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                        'message': "The same unit number can't be used within the same block."
                    },
                    status=status.HTTP_200_OK
                    )

        serializer = UnitSerializer(unit, data=data, partial=True)

        if serializer.is_valid():
            unit = serializer.save()
            if 'images' in request.FILES:
                images = request.FILES.getlist('images')
                for image in images:
                    UnitImage.objects.create(unit=unit, image=image)

            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'Unit updated successfully.',
                             'data': serializer.data}, status=status.HTTP_200_OK)

        return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                         'message': 'Invalid data', 'errors': serializer.errors},
                        status=status.HTTP_200_OK)

    def delete(self, request, pk):
        try:
            # Get the unit to delete
            unit = Unit.objects.get(pk=pk)
            if Application.objects.filter(unit_details=unit).exists():
                return Response(
                    {
                        'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                        'message': 'Cannot delete this unit because there are applications associated with it.'
                    },
                    status=status.HTTP_200_OK
                    )

            # Retrieve related images
            related_images = UnitImage.objects.filter(unit=unit)

            # Delete each image file from the file system
            for unit_image in related_images:
                if unit_image.image:
                    image_path = os.path.join(settings.MEDIA_ROOT, str(unit_image.image))
                    if os.path.exists(image_path):
                        os.remove(image_path)

            # Now delete the images from the database
            related_images.delete()
            unit.is_deleted = True
            unit.save()
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'Unit deleted successfully.'},
                            status=status.HTTP_200_OK)

        except Unit.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Unit not found.'}, status=status.HTTP_200_OK)

class UnitImageDeleteAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def delete(self, request, unit_id, image_id):
        try:
            # Get the unit and make sure it belongs to the user
            unit = Unit.objects.get(pk=unit_id)
        except Unit.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Unit not found.'}, status=status.HTTP_200_OK)
        try:
            # Get the specific image linked to the unit
            unity_image = UnitImage.objects.get(pk=image_id, unit=unit)
            if unity_image.image:
                # Construct the full file path
                image_path = os.path.join(settings.MEDIA_ROOT, str(unity_image.image))
                if os.path.exists(image_path):
                    os.remove(image_path)

            unity_image.delete()
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'Unit Image deleted successfully.'},
                            status=status.HTTP_200_OK)
        except UnitImage.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Image not found.'}, status=status.HTTP_200_OK)

class GetAllUnitAPIView(APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request):
        # Fetch data from POST request body (request.data)
        page = request.data.get('page', 1)
        page_size = request.data.get('page_size', 10)
        search = request.data.get('search', '')
        is_vacant = request.data.get('is_vacant', None)

        # Validate page and page_size to ensure they are integers
        try:
            page = int(page)
            page_size = int(page_size)
        except ValueError:
            return Response({"status": status.HTTP_400_BAD_REQUEST, "result": "0",
                             "message": "Invalid page or page_size. Must be integers."},
                            status=status.HTTP_200_OK)

        # Filter users based on role
        role = request.user.user_role.id
        if role == 3:
            company_id = request.user.company_id
            property_developments = PropertyDevelopment.objects.filter(company=company_id)
            units = Unit.objects.filter(
                property_details__in=property_developments
                ).exclude(is_deleted=True).order_by('-created_at')
        elif role == 4:
            property_developments = PropertyDevelopment.objects.filter(
                property_manager=request.user.id)
            units = Unit.objects.filter(
                property_details__in=property_developments
                ).exclude(is_deleted=True).order_by('-created_at')
        else:
            units = Unit.objects.all().exclude(is_deleted=True).order_by('-created_at')

        # Apply search filter
        if search:
            search_filter = Q()
            search_fields = ['unit_no', 'rent', 'deposit', 'unit_type']
            for field in search_fields:
                search_filter |= Q(**{f"{field}__icontains": search})
            units = units.filter(search_filter)

        # Filter by is_vacant
        if is_vacant is not None:
            if is_vacant.lower() == 'vacant':
                units = units.filter(is_vacant=True)
            elif is_vacant.lower() == 'occupied':
                units = units.filter(is_vacant=False)
            else:
                units = units.all()

        # Apply pagination
        start = (page - 1) * page_size
        end = start + page_size
        paginated_unit = units[start:end]

        serializer = UnitSerializer(paginated_unit, many=True)
        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'message': 'Details retrieved successfully.',
                         'data': serializer.data,
                         'pagination': {'page': page,
                                        'page_size': page_size,
                                        'total_records': units.count(),
                                        'total_pages': (units.count() + page_size - 1) // page_size
                                        }}, status=status.HTTP_200_OK)

class GetApplicationDetailAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, id=None):
        if id:
            try:
                application = Application.objects.get(id=id)
                serializer = ApplicationSerializer(application)
                return Response({'status': status.HTTP_200_OK, 'result': "1",
                                 'message': 'Application fetched successfully.',
                                 'data': serializer.data}, status=status.HTTP_200_OK)

            except Application.DoesNotExist:
                return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                                 'message': 'Application not found.'}, status=status.HTTP_200_OK)
        else:
            role = request.user.user_role.id
            if role == 3:
                company_id = request.user.company_id
                property_developments = PropertyDevelopment.objects.filter(company=company_id)
                units = Unit.objects.filter(property_details__in=property_developments)
                applications = Application.objects.filter(unit_details__in=units).exclude(
                    status__in=["Draft", "Agreement Signed"]).order_by('-id')

            elif role == 4:
                property_developments = PropertyDevelopment.objects.filter(
                    property_manager=request.user.id)
                units = Unit.objects.filter(
                    property_details__in=property_developments).order_by('-created_at')
                applications = Application.objects.filter(unit_details__in=units).exclude(
                    status__in=["Draft", "Agreement Signed"]).order_by('-id')
            else:
                applications = Application.objects.all().exclude(
                    status__in=["Draft", "Agreement Signed"]).order_by('-id')
            serializer = ApplicationSerializer(applications, many=True)
            return Response({'status': status.HTTP_200_OK, 'result': "1",
                             'message': 'All applications fetched successfully.',
                             'data': serializer.data}, status=status.HTTP_200_OK)

    def patch(self, request, id):
        try:
            application = Application.objects.get(id=id)
        except Application.DoesNotExist:
            return Response({'status': status.HTTP_404_NOT_FOUND, 'result': "0",
                             'message': 'Application not found.'}, status=status.HTTP_200_OK)

        new_status = request.data.get('status')
        rejection_message = request.data.get('rejection_message')
        moving_date = request.data.get('moving_date')
        if new_status is None:
            return Response({'status': status.HTTP_400_BAD_REQUEST, 'result': "0",
                             'message': 'Status field is required.'},
                            status=status.HTTP_200_OK)

        # Update the status
        application.status = new_status
        application.rejection_message = rejection_message
        application.moving_date = moving_date
        application.save()

        if new_status == "Rejected":
            application.rejection_blocked_until = now() + timedelta(minutes=2)
            application.save()

        if new_status == "Approved":
            # Get the unit_id of the application
            unit_id = application.unit_details.id

            # Query for all applications with the same unit_id
            all_applications = Application.objects.filter(unit_details__id=unit_id)

            for app in all_applications:
                if app.id != application.id:
                    if app.status != "Rejected":
                        app.status = "Cancelled"
                        app.rejection_message = (
                            "We regret to inform you that your application for this property "
                            "has been cancelled, as the property has been allocated to another applicant."
                        )
                        app.save()
                        if app.user and app.user.email:
                            send_cancelled_application_status_email(app)

            unit = application.unit_details
            unit.is_vacant = False
            unit.save()

        if new_status != "In Review":
            send_application_status_update_email(
                application, new_status, rejection_message, property_details=None)

        if new_status == "Approved":
            generate_lease_agreement(application)

        # Serialize the updated application
        serializer = ApplicationSerializer(application)

        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'message': 'Application status updated successfully.',
                         'data': serializer.data}, status=status.HTTP_200_OK)

class GetAllApplicationView(APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request):
        # Fetch data from POST request body (request.data)
        page = request.data.get('page', 1)
        page_size = request.data.get('page_size', 10)
        search = request.data.get('search', '')
        application_status = request.data.get('application_status', None)

        # Validate page and page_size to ensure they are integers
        try:
            page = int(page)
            page_size = int(page_size)
        except ValueError:
            return Response({"status": status.HTTP_400_BAD_REQUEST, "result": "0",
                             "message": "Invalid page or page_size. Must be integers."},
                            status=status.HTTP_200_OK)

        # Filter users based on role
        role = request.user.user_role.id
        if role == 3:
            company_id = request.user.company_id
            property_developments = PropertyDevelopment.objects.filter(company=company_id)
            units = Unit.objects.filter(property_details__in=property_developments)
            applications = Application.objects.filter(unit_details__in=units).exclude(
                status__in=["Draft", "Agreement Signed"]).order_by('-id')

        elif role == 4:
            property_developments = PropertyDevelopment.objects.filter(
                property_manager=request.user.id)
            units = Unit.objects.filter(
                property_details__in=property_developments).order_by('-created_at')
            applications = Application.objects.filter(unit_details__in=units).exclude(
                status__in=["Draft", "Agreement Signed"]).order_by('-id')
        else:
            applications = Application.objects.all().exclude(
                status__in=["Draft", "Agreement Signed"]).order_by('-id')

        # Apply search filter
        if search:
            search_filter = Q()
            search_fields = ['property_address', 'full_name', 'application_date']
            for field in search_fields:
                search_filter |= Q(**{f"{field}__icontains": search})
            applications = applications.filter(search_filter)

        # Filter by is_vacant
        if application_status is not None:
            if application_status == 'Approved':
                applications = applications.filter(status="Approved")
            elif application_status == 'Rejected':
                applications = applications.filter(status="Rejected")
            elif application_status == 'In Review':
                applications = applications.filter(status="In Review")
            elif application_status == 'Cancelled':
                applications = applications.filter(status="Cancelled")
            else:
                applications = applications.all()

        # Apply pagination
        start = (page - 1) * page_size
        end = start + page_size
        paginated_applications = applications[start:end]

        serializer = ApplicationSerializer(paginated_applications, many=True)
        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'message': 'Details retrieved successfully.',
                         'data': serializer.data,
                         'pagination': {'page': page,
                                        'page_size': page_size,
                                        'total_records': applications.count(),
                                        'total_pages': (applications.count() + page_size - 1)
                                        }}, status=status.HTTP_200_OK)

class CheckAgreementStatusAPI(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request,):
        role = request.user.user_role.id
        if role == 3:
            company_id = request.user.company_id
            property_developments = PropertyDevelopment.objects.filter(company=company_id)
            units = Unit.objects.filter(property_details__in=property_developments)
            applications = Application.objects.filter(
                unit_details__in=units, status="Approved").order_by('-id')

        elif role == 4:
            property_developments = PropertyDevelopment.objects.filter(
                property_manager=request.user.id)
            units = Unit.objects.filter(
                property_details__in=property_developments).order_by('-created_at')
            applications = Application.objects.filter(
                unit_details__in=units, status="Approved").order_by('-id')
        else:
            applications = Application.objects.filter(status="Approved").order_by('-id')

        results = []

        for app in applications:
            document_id = app.lease_agreement_id
            application_id = app.id

            url = f"https://api.pandadoc.com/public/v1/documents/{document_id}/"
            headers = {
                "Authorization": f"API-Key 81f98b3d72276dabde1c9bff1d44bdc683db4814",
                "Content-Type": "application/json"}

            # Sending GET request to check the document status
            response = requests.get(url, headers=headers)

            if response.status_code == 200:
                document_info = response.json()
                if document_info['status'] == 'document.completed':
                    # Update the application status to "Document Completed"
                    d_id = document_info['id']
                    downlod_url = f"https://api.pandadoc.com/public/v1/documents/{d_id}/download"
                    downlod_response = requests.get(downlod_url, headers=headers)

                    if downlod_response.status_code == 200:
                        file_name = f"{d_id}.pdf"  # You can choose the file name dynamically
                        file_content = downlod_response.content
                        agreement_document = AgreementDocument.objects.create(
                            file=ContentFile(file_content, name=file_name)
                        )

                        app.status = "Agreement Signed"
                        app.lease_agreement_documents = agreement_document.file
                        app.save()

                        # Check if a lease already exists for this application
                        existing_lease = Lease.objects.filter(application_details=app).first()
                        if not existing_lease:
                            property_image = PropertyImage.objects.filter(
                                property=app.unit_details.property_details
                                ).first()
                            lease = Lease(
                                application_details=app,
                                unit_details=app.unit_details,
                                applicant_name=app.full_name,
                                applicant_email=app.email,
                                property_name=app.unit_details.property_details,
                                property_address=app.property_address,
                                unit_no=app.unit_details.unit_no,
                                rent=app.unit_details.rent,
                                deposit=app.unit_details.deposit,
                                rental_start_date=app.moving_date,
                                rental_termination_date=app.moving_date + timedelta(days=364),
                                lease_status=app.status,
                                payment_date=None,
                                lease_agreement_documents=agreement_document.file,
                                image=property_image.image if property_image else None
                                )
                            lease.save()
                        else:
                            # If lease exists, update it (if necessary)
                            existing_lease.lease_status = app.status
                            existing_lease.lease_agreement_documents = agreement_document.file
                            existing_lease.save()
                results.append({
                    'application_id': application_id,
                    'document_id': document_info['id'],
                    'status': document_info['status'],
                    'info_message': document_info.get('info_message', 'No additional information')
                })
            else:
                results.append({
                    'application_id': application_id,
                    'document_id': document_id,
                    'error': 'Unable to retrieve document status',
                    'details': response.json() if response.content else 'No response details available'
                })

        # Return all results as a consolidated response
        return Response({'documents': results}, status=status.HTTP_200_OK)

class GetLeaseAPIView(APIView):
    """
    This view handles the retrieval of lease details based on user role and
    performs search and pagination on the lease records.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request, id=None):
        """
        Handles the POST request to fetch lease details. The lease details are
        filtered based on the user's role, optional search criteria, and
        pagination.
        """
        page = request.data.get('page', 1)
        page_size = request.data.get('page_size', 10)
        search = request.data.get('search', '')

        # Validate page and page_size to ensure they are integers
        try:
            page = int(page)
            page_size = int(page_size)
        except ValueError:
            return Response({"status": status.HTTP_400_BAD_REQUEST, "result": "0",
                             "message": "Invalid page or page_size. Must be integers."},
                            status=status.HTTP_200_OK)

        # Filter users based on role
        role = request.user.user_role.id
        if role == 3:
            company_id = request.user.company_id
            property_developments = PropertyDevelopment.objects.filter(company=company_id)
            units = Unit.objects.filter(property_details__in=property_developments)
            lease = Lease.objects.filter(unit_details__in=units).order_by('-id')
        elif role == 4:
            property_developments = PropertyDevelopment.objects.filter(
                property_manager=request.user.id)
            units = Unit.objects.filter(
                property_details__in=property_developments).order_by('-created_at')
            lease = Lease.objects.filter(unit_details__in=units).order_by('-id')
        else:
            lease = Lease.objects.all().order_by('-id')

        # Apply search filter
        if search:
            search_filter = Q()
            search_fields = ['applicant_name', 'property_name', 'property_address',
                             'rental_start_date', 'rental_termination_date', 'rent']
            for field in search_fields:
                search_filter |= Q(**{f"{field}__icontains": search})
            lease = lease.filter(search_filter)

        # Apply pagination
        start = (page - 1) * page_size
        end = start + page_size
        paginated_lease = lease[start:end]

        serializer = LeaseSerializer(paginated_lease, many=True)
        return Response({'status': status.HTTP_200_OK, 'result': "1",
                         'message': 'Details retrieved successfully.',
                         'data': serializer.data,
                         'pagination': {'page': page,
                                        'page_size': page_size,
                                        'total_records': lease.count(),
                                        'total_pages': (lease.count() + page_size - 1)
                                        }}, status=status.HTTP_200_OK)
