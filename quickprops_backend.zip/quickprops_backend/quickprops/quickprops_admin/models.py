"""
This module contains models for the property development application.
"""
from django.db import models
from quickprops_app.models import User, Company

class PropertyDevelopment(models.Model):
    """
    This model represents a property development entity.
    It stores details about a property, including its name, type, address,
    location, security features, nearby transport options, and other
    relevant attributes. It also includes references to the user, property
    manager, and company managing the property.
    """
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    property_manager = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True, related_name='property_manager')
    company = models.ForeignKey(
        Company, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='assign_company_name')
    property_name = models.CharField(max_length=255, null=True, blank=True)
    property_type = models.CharField(max_length=255, null=True, blank=True)
    address = models.CharField(max_length=255, null=True, blank=True)
    city = models.CharField(max_length=255, null=True, blank=True)
    province = models.CharField(max_length=255, null=True, blank=True)
    security_features = models.JSONField(null=True, blank=True)
    nearby_transport = models.JSONField(null=True, blank=True)
    property_status = models.BooleanField(default=True)
    latitude = models.CharField(max_length=255, null=True, blank=True)
    longitude = models.CharField(max_length=255, null=True, blank=True)
    is_deleted = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return str(self.property_name)

class PropertyImage(models.Model):
    """
    This model represents an image associated with a property.
    It stores the image file along with the property it is related to.
    Each property can have multiple images linked to it.
    """
    property = models.ForeignKey(
        PropertyDevelopment, related_name='images', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='property_images/')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Block(models.Model):
    """
    This model represents a block within a property development.
    It stores information about the block name, the number of units,
    and other related features such as common area features and block status.
    Each block is associated with a specific property development.
    """
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    property_details = models.ForeignKey(
        PropertyDevelopment, on_delete=models.CASCADE, related_name='blocks')
    block_name = models.CharField(max_length=255, null=True, blank=True)
    number_of_units = models.IntegerField()
    common_area_features = models.JSONField(null=True, blank=True)
    block_status = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return str(self.block_name)

class Unit(models.Model):
    """
    This model represents a unit within a property block.
    It stores information about the unit type, number of bedrooms,
    bathrooms, balconies, parking spaces, and other features related to the unit.
    It also includes rent details, availability, and unit-specific amenities.
    Each unit is associated with a specific property and block.
    """
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    property_details = models.ForeignKey(
        PropertyDevelopment, on_delete=models.CASCADE, null=True, blank=True, related_name='units')
    block_details = models.ForeignKey(
        Block, on_delete=models.CASCADE, null=True, blank=True, related_name='units')
    unit_type = models.CharField(max_length=255, null=True, blank=True)
    number_of_bedrooms = models.IntegerField()
    number_of_bathrooms = models.IntegerField()
    number_of_balconies = models.IntegerField()
    parking_spaces = models.IntegerField()
    pet_policy = models.BooleanField(default=True)
    furnishing_status = models.BooleanField(default=True)
    additional_amenities = models.JSONField(null=True, blank=True)
    unit_security_features = models.JSONField(null=True, blank=True)
    unit_no = models.IntegerField(null=True, blank=True)
    rent = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    deposit = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    available_from = models.DateField(null=True, blank=True)
    unit_description = models.TextField(null=True, blank=True)
    unit_status = models.BooleanField(default=True)
    is_vacant = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Unit in {self.unit_no} - {self.unit_type}"

class UnitImage(models.Model):
    """
    This model represents an image associated with a unit.
    It stores the unit image and its creation and update timestamps.
    Each image is linked to a specific unit.
    """
    unit = models.ForeignKey(Unit, related_name='images', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='unit_images/')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class CMS(models.Model):
    """
    This model represents a CMS entity.
    It stores a title and content.
    """
    title = models.CharField(max_length=255, null=True, blank=True)
    content = models.TextField(null=True, blank=True)

    def __str__(self):
        return str(self.title)
