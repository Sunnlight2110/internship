from django.urls import path
from .views import *
from .cms import CMSView
from .permissions import PermissionView

urlpatterns = [
    path('login/', LoginAPIView.as_view(), name='admin-login'),
    path('forgetpassword-mail/', ForgetPasswordSendMail.as_view(), name='forgot-password-mail'),
    path('resend-otp/', ResendOTPView.as_view(), name='customer-resend-otp'),
    path('otp-verify/', OTPVerificationView.as_view(), name='otp-verify'),
    path('forget-password/', ForgetPassword.as_view(), name='forget-password'),
    path('change-password/', ChangePassword.as_view(), name='customer-change-password'),
    path('logout/', AdminLogoutAPI.as_view(), name='logout'),

    path('get-profile/', UserProfileAPI.as_view(), name='get-profile'),
    path('company_update/<int:pk>/', CompanyUpdateAPIView.as_view(), name='company-update'),
    path('dashboardview/', DashboardAPIView.as_view(), name='dashboardview'),

    # Company APIs
    path('user_details/', CreateUserAPIView.as_view(), name='create_user'),
    path('get_all_users/', GetAllUserAPIView.as_view(), name='get-all-users'),
    path('user_details/<int:user_id>/', CreateUserAPIView.as_view(), name='user-detail'),
    path('get_company_name/', GetCompanyDetailsAPIView.as_view(), name='user-details'),
    path('get_property_managers/', ListPropertyManagerAPIView.as_view(), name='get-property-managers'),

    # Property APIs
    path('property_development/', PropertyDevelopmentAPIView.as_view(), name='property-development'),
    path('get_all_property/', GetAllPropertyAPIView.as_view(), name='get-all-property'),
    path('property_development/<int:pk>/', PropertyDevelopmentAPIView.as_view(), name='property-development-detail'),
    path('property/<int:pk>/image/<int:image_id>/', PropertyImageDeleteAPIView.as_view(), name='delete-property-image'),

    # Block APIs
    path('blocks/', BlockAPIView.as_view(), name='block-list-create'),
    path('get_all_block/', GetAllBlockAPIView.as_view(), name='get-all-block'),
    path('blocks/<int:pk>/', BlockAPIView.as_view(), name='block-detail'),
    path('property/<int:property_id>/blocks/', BlocksByPropertyAPIView.as_view(), name='blocks_by_property'),

    # Unit APIs
    path('units/', UnitAPIView.as_view(), name='units-list-create'),
    path('get_all_unit/', GetAllUnitAPIView.as_view(), name='get-all-unit'),
    path('units/<int:pk>/', UnitAPIView.as_view(), name='units-detail'),
    path('units/<int:unit_id>/image/<int:image_id>/', UnitImageDeleteAPIView.as_view(), name='unit-image-delete'),

    # Applications APIs
    path('get_application/', GetApplicationDetailAPIView.as_view(), name='get-applications-list'),
    path('get_all_application/', GetAllApplicationView.as_view(), name='get-all-application'),
    path('get_application/<int:id>/', GetApplicationDetailAPIView.as_view(), name='get-application-detail'),
    path('check_agreement_status/', CheckAgreementStatusAPI.as_view(), name='check-agreement-status'),

    # Lease API
    path('get_all_lease/', GetLeaseAPIView.as_view(), name='get-all-lease'),

    # CMS View
    path('cms/', CMSView.as_view(), name='cms-list-create'),
    path('cms/<int:pk>/', CMSView.as_view(), name='cms-detail'),

    # Permission View
    path('permissions_view/', PermissionView.as_view(), name='create-permission'),
]
