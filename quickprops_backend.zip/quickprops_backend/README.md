# Project Setup Instructions

Welcome to the Quickprops project! Follow the steps below to set up and run the project on your system.

---

## Git Clone

To get the project on your system, you need to clone the repository using Git:

1. **Clone the Project**:
   - Run the following command in your terminal or command prompt (replace `your-repository-url` with your actual Git repository URL):
     ```
     git clone your-repository-url
     ```

2. **Navigate to the Project Directory**:
   - After cloning the repository, navigate to the project directory:
     ```
     cd path\\to\\your\\cloned\\project
     ```

3. **Switch to the Latest Branch**:
   - By default, the clone will check out the default branch (usually `main` or `master`). To switch to the latest branch, use the following command:
     ```
     git checkout latest-branch-name
     ```
   - Replace `latest-branch-name` with the actual name of the latest branch you need to work with.

---

## .env File Setup

The project requires environment variables for local database connection, email OTP, phone OTP, and other services. You need to create a `.env` file in the project root directory and add the following content:

1. **Create the `.env` file** in the same directory as your `settings.py` file (usually inside the project folder).
2. **Add the following environment variables**:

   ```ini
   #-----------Database Connection -------------------------------
   ENGINE=django.db.backends.postgresql
   DB_NAME=quickprops_app
   POSTGRES_USER=
   POSTGRES_PASSWORD=
   DB_HOST=localhost
   DB_PORT=5432
   
   #----------------------- BULK SMS ----------------------------------------------
   MY_SMS_USERNAME=quickprop
   MY_PASSWORD=Quickprop@1 
   
   #----------------------- SENDGRID  ----------------------------------------------
   SENDGRID_API_KEY=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
   SENDGRID_EMAIL=hartik.rathod@techcronus.com

   #----------------------- AKIBAONE  ----------------------------------------------
   AKIBAONE_API_KEY=5b955797-265c-4bc2-a662-24fb28574f56
   AKIBAONE_API_SECRET_KEY=b9d9f5219234211da8bee1e78d7b2cbf12a11354d1a817f0252563c9bd376bcc

   #---------------------------------------------------------Pandadoc---------------------------
   PANDADOC_API_KEY=81f98b3d72276dabde1c9bff1d44bdc683db4814
   PANDADOC_TEMPLATE_ID=Whc5yU57krr4bzHEQ5yVA9

---

## Ubuntu Setup

1. **Install Python**:
   - To install Python on Ubuntu:
     ```
     sudo apt update
     sudo apt install python3
     ```

2. **Install PIP**:
   - If PIP is not installed, run the following:
     ```
     sudo apt install python3-pip
     ```

3. **Install Virtual Environment**:
   - To install virtual environment:
     ```
     sudo apt install python3-venv
     ```

4. **Create Virtual Environment**:
   - To create a virtual environment:
     ```
     python3 -m venv venv
     ```

5. **Activate Virtual Environment**:
   - To activate the virtual environment on Ubuntu:
     ```
     source venv/bin/activate
     ```

6. **Install Required Libraries**:
   - To install the required libraries from the `requirements.txt` file:
     ```
     pip install -r requirements.txt
     ```

7. **Database Migrations**:
   - If your project includes a database, apply the migrations using the following command:
     ```
     python3 manage.py migrate
     ```
     
8. **Run Seeder File:**:
   - This command will populate your database and create the initial user roles, including super admin, and assign the necessary permissions.
     ```
     python3 manage.py loaddata user_roles_and_admin.json
     ```

9. **Start the Server**:
   - To start the Django server:
     ```
     python3 manage.py runserver
     ```

   - Once the server is running successfully, you can access the project in your browser at `http://127.0.0.1:8000/`.

10. **Super Admin Login:**:
   - After successfully setting up the server, you can log in as the super admin using the following credentials:
     ```
     Email: quickprop@yopmail.com
     Password: Test@123#
     ```

---

## Windows Setup

1. **Install Python**:
   - First, you need to install Python. You can download it from the [official Python website](https://www.python.org/downloads/).
   - During the installation, make sure to select the "Add Python to PATH" option.

2. **Install PIP**:
   - PIP comes installed with Python, but if it's not installed, you can install it using the following command:
     ```
     python -m ensurepip --upgrade
     ```

3. **Install Virtual Environment**:
   - To install the virtual environment, run the following in your command prompt:
     ```
     pip install virtualenv
     ```

4. **Create Virtual Environment**:
   - To create a virtual environment:
     ```
     python -m venv venv
     ```

5. **Activate Virtual Environment**:
   - To activate the virtual environment on Windows:
     ```
     venv\\Scripts\\activate
     ```

6. **Install Required Libraries**:
   - To install all the required libraries from the `requirements.txt` file:
     ```
     pip install -r requirements.txt
     ```

7. **Database Migrations**:
   - If your project has a database configuration, run the following command to apply migrations:
     ```
     python manage.py migrate
     ```
     
8. **Run Seeder File:**:
   - This command will populate your database and create the initial user roles, including super admin, and assign the necessary permissions.
     ```
     python3 manage.py loaddata user_roles_and_admin.json
     ```

9. **Start the Server**:
   - To start the Django server:
     ```
     python3 manage.py runserver
     ```

   - Once the server is running successfully, you can access the project in your browser at `http://127.0.0.1:8000/`.

10. **Super Admin Login:**:
   - After successfully setting up the server, you can log in as the super admin using the following credentials:
     ```
     Email: quickprop@yopmail.com
     Password: Test@123#
     ```

---

## Notes

- The default port for Django is 8000. If you want to run the server on a different port, you can specify the port number like this:
  ```bash
  python manage.py runserver <port_number>
